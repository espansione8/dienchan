import type { PageServerLoad, Actions } from './$types'
import type { CartItem, DiscountItem } from '$lib/types';
import { BASE_URL, APIKEY, SALT, STRIPE_KEY_FRONT, STRIPE_KEY_BACK } from '$env/static/private';
import { fail, error } from '@sveltejs/kit';
import { pageAuth } from '$lib/pageAuth';
import { hash } from '$lib/tools/hash';
import { customAlphabet } from 'nanoid'
import Stripe from 'stripe';
const nanoid = customAlphabet('123456789ABCDEFGHJKLMNPQRSTUVWXYZ', 9)
const stripe = new Stripe(STRIPE_KEY_BACK, {
	apiVersion: '2025-12-15.clover' // Use a stable API version https://docs.stripe.com/api/versioning
});

export const load: PageServerLoad = async ({ locals, fetch, url }) => {
	pageAuth(url.pathname, locals.auth, 'page');

	return {
		userData: locals.user || null,
		auth: locals.auth,
		stripePublishableKey: STRIPE_KEY_FRONT
	};
};

// calculate discount for a single item used in applyDiscount/removeDiscount 
const calculateItemDiscount = (
	discount: DiscountItem,
	cartArray: CartItem[],
	originalTotal: number
): number => {
	const { type, value, selectedApplicability } = discount;
	let totalDiscount = 0;

	// Gestione sconto QUANTITÀ
	if (selectedApplicability === 'prodId' && discount.qty && discount.qty > 1) {
		cartArray.forEach((item: CartItem) => {
			if (item.prodId === discount.prodId) {
				const itemQty = typeof item.orderQuantity === 'number' && item.orderQuantity > 0
					? item.orderQuantity
					: 1;

				// Verifica se la quantità nel carrello soddisfa la soglia minima
				if (itemQty >= discount.qty) {
					const numericPrice = Number(item.price);
					if (!Number.isFinite(numericPrice)) {
						throw new Error('Errore calcolo prezzo non valido');
					}

					let itemDiscount = 0;

					if (type === 'amount') {
						// Quante volte si applica la soglia
						const times = Math.floor(itemQty / discount.qty);
						itemDiscount = value * times;
					} else if (type === 'percent') {
						// Sconto percentuale sul totale dei prodotti
						const totalValue = numericPrice * itemQty;
						itemDiscount = (totalValue * value) / 100;
					}

					totalDiscount += itemDiscount;
				}
			}
		});
	}

	// Gestione sconto PRODOTTO SINGOLO (senza qty)
	else if (selectedApplicability === 'prodId' && (!discount.qty || discount.qty <= 1)) {
		cartArray.forEach((item: CartItem) => {
			if (item.prodId === discount.prodId) {
				const itemQty = typeof item.orderQuantity === 'number' && item.orderQuantity > 0
					? item.orderQuantity
					: 1;
				let itemDiscount = 0;
				const numericPrice = Number(item.price);

				if (!Number.isFinite(numericPrice)) {
					throw new Error('Errore calcolo');
				}

				if (type === 'amount') {
					itemDiscount = value * itemQty;
				} else if (type === 'percent') {
					const singleValue = (numericPrice * value) / 100;
					itemDiscount = singleValue * itemQty;
				}
				totalDiscount += itemDiscount;
			}
		});
	}
	else if (selectedApplicability === 'layoutId') {
		cartArray.forEach((item: CartItem) => {
			if (item.layoutView?.layoutId === discount.layoutId) {
				const qty = typeof item.orderQuantity === 'number' && item.orderQuantity > 0
					? item.orderQuantity
					: 1;
				let itemDiscount = 0;
				const numericPrice = Number(item.layoutView.price);
				if (!Number.isFinite(numericPrice)) {
					throw new Error('Errore calcolo');
				}
				if (type === 'amount') {
					itemDiscount = value * qty;
				} else if (type === 'percent') {
					const singleValue = (numericPrice * value) / 100;
					itemDiscount = singleValue * qty;
				}
				totalDiscount += itemDiscount;
			}
		});
	}
	else if (selectedApplicability === 'email' || selectedApplicability === 'membershipLevel' || selectedApplicability === 'riflessologo') {
		if (type === 'amount') {
			totalDiscount = value;
		} else if (type === 'percent') {
			totalDiscount = (originalTotal * value) / 100;
		}
	}
	else if (selectedApplicability === 'referral') {
		totalDiscount = (originalTotal * discount.refDiscount) / 100;
	}

	return totalDiscount;
}

export const actions: Actions = {

	createPaymentIntent: async ({ request, locals }) => {
		try {
			const formData = await request.formData();
			const totalValue = formData.get('totalValue') as string;
			const email = formData.get('email')?.toString().toLowerCase().trim();
			const name = formData.get('name') as string;
			const surname = formData.get('surname') as string;

			if (!totalValue || !email) {
				return fail(400, {
					action: 'createPaymentIntent',
					success: false,
					message: 'Dati mancanti'
				});
			}

			const amountInCents = Math.round(Number(totalValue) * 100);

			// Create PaymentIntent WITHOUT confirming
			const paymentIntent = await stripe.paymentIntents.create({
				amount: amountInCents,
				currency: 'eur',
				automatic_payment_methods: {
					enabled: true
				},
				metadata: {
					email,
					name: `${name.trim()} ${surname.trim()}`
				},
				// Request 3DS when needed
				payment_method_options: {
					card: {
						request_three_d_secure: 'automatic'
					}
				}
			});
			// 	In the context of Stripe's API, request_three_d_secure can be set to:
			// 'any' – for trying 3DS with a preference for a frictionless or challenge flow.
			// 'challenge' – explicitly requesting an active challenge flow.
			// 'automatic' – letting Stripe decide dynamically based on risk.
			// 'off' – explicitly avoiding 3DS authentication.

			// console.log('paymentIntent.id', paymentIntent.id);
			// console.log('paymentIntent.client_secret', paymentIntent.client_secret);

			return {
				action: 'createPaymentIntent',
				success: true,
				payload: {
					clientSecret: paymentIntent.client_secret,
					paymentIntentId: paymentIntent.id
				}
			};
		} catch (err: any) {
			console.error('PaymentIntent creation error:', err);
			return fail(400, {
				action: 'createPaymentIntent',
				success: false,
				message: `Errore creazione pagamento: ${err.message}`
			});
		}
	},

	new: async ({ request, fetch, locals, cookies }) => {
		const formData = await request.formData();
		const name = formData.get('name');
		const surname = formData.get('surname');
		const email = formData.get('email');
		const address = formData.get('address');
		const city = formData.get('city');
		const county = formData.get('county');
		const postalCode = formData.get('postalCode');
		const country = formData.get('country');
		const phone = formData.get('phone') || '';
		const mobilePhone = formData.get('mobilePhone') || '';
		const payment = formData.get('payment');
		const password1: any = formData.get('password1') || '';
		const password2 = formData.get('password2') || '';
		const totalValue = Number(formData.get('totalValue'));
		const cart = formData.get('cart');
		//const discountList = formData.get('discountList')
		const discountList = formData.get('discountList') as string;
		const cartItem = JSON.parse(String(cart)) || null;
		const discountItem = JSON.parse(String(discountList)) || [];
		const discountArray: string[] = JSON.parse(discountList || '[]').map(item => item.code);
		const newPointsBalance = Number(formData.get('newPointsBalance'));
		const usedPoints = Number(formData.get('usedPoints')) || 0;
		const usePoint = formData.get('usePoint') === 'true' // 'true' make it boolean
		// const paymentMethodId = formData.get('paymentMethodId') as string | null;
		const paymentIntentId = formData.get('paymentIntentId') as string | null; // Changed from paymentMethodId
		const storePickUp = formData.get('storePickUp') === 'true' // 'true' make it boolean
		const orderNotes = formData.get('orderNotes') as string | null;
		const shippingName = formData.get('shippingName');
		const shippingSurname = formData.get('shippingSurname');
		const shippingEmail = formData.get('shippingEmail');
		const shippingPhone = formData.get('shippingPhone');
		const shippingMobilePhone = formData.get('shippingMobilePhone');
		const shippingAddress = formData.get('shippingAddress');
		const shippingCity = formData.get('shippingCity');
		const shippingCounty = formData.get('shippingCounty');
		const shippingPostalCode = formData.get('shippingPostalCode');
		const shippingCountry = formData.get('shippingCountry');

		const finalShippingData = storePickUp ? {
			name: '',
			surname: '',
			email: '',
			phone: '',
			mobilePhone: '',
			address: 'Ritiro in sede',
			city: '',
			county: '',
			postalCode: '',
			country: ''
		} : {
			name: shippingName,
			surname: shippingSurname,
			email: shippingEmail,
			phone: shippingPhone,
			mobilePhone: shippingMobilePhone,
			address: shippingAddress,
			city: shippingCity,
			county: shippingCounty,
			postalCode: shippingPostalCode,
			country: shippingCountry
		};

		if (usePoint && newPointsBalance < 0) {
			return fail(400, { action: 'new', success: false, message: 'Saldo punti insufficiente' });
		}



		// Calculate total cart on server anche for security
		const cartRecalculated = () => {
			let total = 0;
			//total += 9 //delivery fee
			cartItem.forEach((element: any) => {
				if (element.type == 'course') {
					total += element.layoutView.price * (element.orderQuantity || 1);
				} else {
					total += element.price * (element.orderQuantity || 1);
				}
			});
			return total;
		};

		let totalDiscount = 0
		if (usePoint) {
			totalDiscount = discountItem.reduce((acc, element: any) => acc + (element.totalDiscount || 0), 0) + usedPoints
		} else {
			totalDiscount = discountItem.reduce((acc, element: any) => acc + (element.totalDiscount || 0), 0)
		}

		//const totalDiscount = discountItem.reduce((acc, element: any) => acc + (element.totalDiscount || 0), 0)

		//let recalculatedTotal = cartRecalculated() - totalDiscount;
		const recalculatedTotal = () => {
			let total = cartRecalculated() - totalDiscount;
			// console.log('cartRecalculated()', cartRecalculated())
			// console.log('totalDiscount', totalDiscount)
			if (cartRecalculated() < 100 && !storePickUp) {
				total += 9; // Add delivery fee if total is below 100
			}
			return total;
		};
		// console.log('totalValue', Number(totalValue));
		// console.log('recalculatedTotal', recalculatedTotal());
		// return

		if (Number(totalValue) !== recalculatedTotal()) {
			return fail(400, { action: 'new', success: false, message: 'Totale non valido' });
		}

		// Crea la stringa con gli sconti applicati
		const discountNotes = (() => {
			if (!discountList || discountList === '[]') return '';

			try {
				const discounts = JSON.parse(discountList);
				if (!Array.isArray(discounts) || discounts.length === 0) return '';

				const discountCodes = discounts.map(item => item.code).join(', ');
				return `Codici sconto applicati: ${discountCodes}`;
			} catch (error) {
				console.error('Error parsing discountList:', error);
				return '';
			}
		})();

		// Fai l'append delle note sconti alle note esistenti
		const finalNotes = orderNotes && discountNotes
			? `${orderNotes} - ${discountNotes}`
			: orderNotes || discountNotes;

		const mailFetch = (email, order) => fetch(`${BASE_URL}/api/mailer/new-order`, {
			method: 'POST',
			body: JSON.stringify({
				apiKey: APIKEY,
				email,
				order
			}),
			headers: {
				'Content-Type': 'application/json'
			}
		});

		//const file = formData.get('image') || '';
		//console.log(name, surname, email, address, city, county, postalCode, country, phone, mobilePhone, payment, password1, password2, totalValue, cartItem);
		let currentUserId: string = locals.user?.userId ?? '';

		if (!locals.auth) {
			if (!password1 || !password2 || password1.length < 8) {
				return fail(400, { action: 'new', success: false, message: 'Password troppo corta' });
			}
			if (password1 !== password2) {
				return fail(400, { action: 'new', success: false, message: 'Password non corrispondenti' });
			}
		}

		if (!name || !surname || !email || !address || !city || !county || !postalCode || !country || !payment || cartItem.length < 1) {
			return fail(400, { action: 'new', success: false, message: 'Dati mancanti' });
		}

		// Stripe payment processing
		// let paymentIntentId: string | null = null;
		const amountInCents = Math.round(Number(totalValue) * 100);
		let paymentVerified = false;
		if (payment === 'Carta di credito') {

			// if (!paymentMethodId) {
			if (!paymentIntentId) {
				return fail(400, {
					action: 'new',
					success: false,
					message: 'ID metodo di pagamento non valido.'
				});
			}

			if (amountInCents < 50) {
				return fail(400, {
					action: 'new',
					success: false,
					message: `Pagamenti con carta solo per importi superiori a € 0.50`
				});
			}

			// try {
			// 	const paymentIntent = await stripe.paymentIntents.create({
			// 		amount: amountInCents,
			// 		currency: 'eur',
			// 		payment_method: paymentMethodId,
			// 		confirm: true,
			// 		automatic_payment_methods: { enabled: true, allow_redirects: 'never' }
			// 	});
			// 	// console.log('paymentIntent.status', paymentIntent.status)
			// 	// paymentIntentId = paymentIntent.id;
			// 	if (paymentIntent.status === 'succeeded') {
			// 		paymentIntentId = paymentIntent.id;
			// 	} else {
			// 		return fail(400, {
			// 			action: 'new',
			// 			success: false,
			// 			message: `Pagamento fallito: ${paymentIntent.status}`
			// 		});
			// 	}
			// } catch (err: any) {
			// 	console.error('Stripe error:', err);
			// 	return fail(400, {
			// 		action: 'new',
			// 		success: false,
			// 		message: `Pagamento fallito: ${err.message}`
			// 	});
			// }

			try {
				const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

				if (paymentIntent.status !== 'succeeded') {
					return fail(400, {
						action: 'new',
						success: false,
						message: `Pagamento non completato: ${paymentIntent.status}`
					});
				}
				paymentVerified = true;
			} catch (err: any) {
				console.error('PaymentIntent verification error:', err);
				return fail(400, {
					action: 'new',
					success: false,
					message: `Errore verifica pagamento: ${err.message}`
				});
			}

		}

		if (!locals.auth) {
			let userExist = false;
			try {
				const res = await fetch(`${BASE_URL}/api/mongo/find`, {
					method: 'POST',
					body: JSON.stringify({
						apiKey: APIKEY,
						schema: 'user', //product | order | user | layout | discount
						query: { email },
						projection: { email: 1 },
						sort: { createdAt: -1 },
						limit: 1,
						skip: 0
					}),
					headers: {
						'Content-Type': 'application/json'
					}
				});
				if (!res.ok) {
					console.error('user fetch failed', res.status, await res.text());
					return fail(400, { action: 'new', success: false, message: 'errore database user' });
				}
				const response = await res.json();
				if (response.length > 0) {
					userExist = true;
					return fail(400, { action: 'new', success: false, message: 'email esistente' });
				}
			} catch (err) {
				console.log('userCheck error:', err);
				return fail(400, { action: 'new', success: false, message: 'userCheck error' });
			}
			if (!userExist) {
				try {
					const cookieId = crypto.randomUUID()

					const res = await fetch(`${BASE_URL}/api/mongo/create`, {
						method: 'POST',
						body: JSON.stringify({
							apiKey: APIKEY,
							schema: 'user', //product | order | user | layout | discount
							newDoc: {
								userId: nanoid(),
								userCode: crypto.randomUUID(),
								name,
								surname,
								email,
								address,
								postalCode,
								city,
								county,
								country,
								phone,
								mobilePhone,
								password: hash(password1, SALT),
								cookieId,
								// "membership.membershipLevel": 'Socio ordinario',
								// "membership.membershipSignUp": new Date(),
								// "membership.membershipActivation": new Date(),
								// "membership.membershipExpiry": new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
								// "membership.membershipStatus": true
							},
							returnObj: true
						}),
						headers: {
							'Content-Type': 'application/json'
						}
					});
					if (!res.ok) {
						return fail(400, { action: 'user', success: false, message: await res.text() });
					}
					const response = await res.json();
					currentUserId = response.userId;

					cookies.set('session_id', cookieId, {
						httpOnly: true,
						//maxAge: 60 * 60 * 24 * 7 // one week
						maxAge: 60 * 60 * 24, // one day
						sameSite: 'lax',
						secure: process.env.NODE_ENV === 'production',
						path: '/'
					});

				} catch (error) {
					console.error('Error creating new user:', error);
					return fail(400, { action: 'user', success: false, message: 'Error new user' });
				}
			}
		}

		try {
			const orderId = nanoid() // OLD stringHash(crypto.randomUUID());
			const orderCode = crypto.randomUUID()

			const newDoc = {
				orderId,
				orderCode,
				userId: currentUserId,
				status: 'requested',
				orderDate: new Date(),
				orderConfirmDate: null,
				promotionId: '',
				promotionName: '',
				promoterId: '',
				agencyId: '',
				orderConfirmed: false,
				totalPoints: usedPoints,
				totalValue: totalValue,
				totalDiscount: Number(totalDiscount),
				totalVAT: 0,
				browser: '',
				orderIp: '',
				orderNotes: finalNotes,
				type: 'product',
				invoicing: {
					name,
					surname,
					businessName: '',
					vatNumber: '',
					address,
					city,
					county,
					postalCode,
					state: '',
					region: '',
					country,
					invoiceNotes: '',
					email,
					phone,
					mobilePhone
				},
				shipping: {
					name: finalShippingData.name,
					surname: finalShippingData.surname,
					address: finalShippingData.address,
					city: finalShippingData.city,
					county: finalShippingData.county,
					postalCode: finalShippingData.postalCode,
					state: '',
					region: '',
					country: finalShippingData.country,
					deliveryNotes: '',
					email: finalShippingData.email,
					phone: finalShippingData.phone,
					mobilePhone: finalShippingData.mobilePhone,
				},
				storePickUp,
				payment: {
					method: payment,
					statusPayment: paymentIntentId ? 'done' : 'pending',
					transactionId: paymentIntentId || '',
					points: '',
					value: ''
				},
				cart: cartItem
			};
			const res = await fetch(`${BASE_URL}/api/mongo/create`, {
				method: 'POST',
				body: JSON.stringify({
					apiKey: APIKEY,
					schema: 'order', //product | order | user | layout | discount
					newDoc,
					returnObj: true
				}),
				headers: {
					'Content-Type': 'application/json'
				}
			});

			if (!res.ok) {
				return fail(400, { action: 'new', success: false, message: await res.text() });
			}

			const order = await res.json();


			const mailArray = ['powerperformance.vn@gmail.com', email]
			const mailRes = await mailFetch(mailArray, order);
			if (!mailRes.ok) {
				console.error('Mail sending failed:', await mailRes.text());
			}

			const updateQty = cartItem.map(async (item) => {
				const updateQtyRes = await fetch(`${BASE_URL}/api/mongo/update`, {
					method: 'POST',
					body: JSON.stringify({
						apiKey: APIKEY,
						schema: 'product',
						query: { prodId: item.prodId },
						update: {
							$inc: {
								stockQty: -item.orderQuantity
							}
						},
						options: { upsert: false },
						multi: false
					}),
					headers: {
						'Content-Type': 'application/json'
					}
				});

				if (!updateQtyRes.ok) {
					const errorData = await updateQtyRes.json();
					console.error(`Failed to update prodId ${item.prodId}:`, errorData);
					throw new Error(`Failed to update stock for ${item.prodId}`); // return fail do not stop the map and don't trigger try/catch
				}
				return updateQtyRes.json();
			});

			await Promise.all(updateQty);

			if (discountArray.length > 0) {
				// Calc discount points for user
				const discountRes = await fetch(`${BASE_URL}/api/mongo/find`, {
					method: 'POST',
					body: JSON.stringify({
						apiKey: APIKEY,
						schema: 'discount',
						query: { code: { $in: discountArray }, type: 'referral' },
						projection: { _id: 0 },
						sort: { createdAt: -1 },
						limit: 1,
						skip: 0
					}),
					headers: {
						'Content-Type': 'application/json'
					}
				});

				if (!discountRes.ok) {
					return fail(400, { action: 'new', success: false, message: await discountRes.text() });
				}
				const discount = await discountRes.json();
				//console.log('discount', discount);

				if (discount.length > 0 && discount[0].referral) {
					// if (!discount[0].email) {
					// 	console.error('no refPoint email found');
					// 	return fail(400, { action: 'new', success: false, message: 'no refPoint email found' });
					// }
					const calcPoint = Math.round(totalValue * discount[0].refPoints / 100);

					const updateRes = await fetch(`${BASE_URL}/api/mongo/update`, {
						method: 'POST',
						body: JSON.stringify({
							apiKey: APIKEY,
							schema: 'user', //product | order | user | layout | discount
							query: { email: discount[0].referral },
							update: {
								$inc: {
									pointsBalance: calcPoint
								},
								$push: {
									pointsHistory: {
										points: calcPoint,
										note: `punti per ordine: ${orderId}`
									}
								}
							},
							options: { upsert: false },
							multi: false
						}),
						headers: {
							'Content-Type': 'application/json'
						}
					});
					if (!updateRes.ok) {
						const errorText = await updateRes.text();
						console.error('user update failed', updateRes.status, errorText);
						return fail(400, { action: 'modifyPoints', success: false, message: errorText });
					}

					const mailFetch = await fetch(`${BASE_URL}/api/mailer/default`, {
						method: 'POST',
						body: JSON.stringify({
							apiKey: APIKEY,
							email: discount[0].referral,
							content: `Hai ricevuto punti dal tuo codice formatore: ${discount[0].code} per l'ordine: ${orderId}`
						}),
						headers: {
							'Content-Type': 'application/json'
						}
					});
					if (!mailFetch.ok) {
						console.error('Referral Mail sending failed:', await mailFetch.text());
					}
				}
			}

			if (usePoint) {
				const updatePoint = await fetch(`${BASE_URL}/api/mongo/update`, {
					method: 'POST',
					body: JSON.stringify({
						apiKey: APIKEY,
						schema: 'user', //product | order | user | layout | discount
						query: { userId: currentUserId },
						update: {
							$set: {
								pointsBalance: Math.round(newPointsBalance)
							},
							$push: {
								pointsHistory: {
									points: -usedPoints,
									note: `punti utilizzati per ordine: ${orderId}`
								}
							}
						},
						options: { upsert: false },
						multi: false
					}),
					headers: {
						'Content-Type': 'application/json'
					}
				});
				if (!updatePoint.ok) {
					const errorText = await updatePoint.text();
					console.error('user points update failed', updatePoint.status, errorText);
					return fail(400, { action: 'new: update points balance', success: false, message: errorText });
				}
			}

			if (locals.auth) {
				return { action: 'new', success: true, message: "L'ordine è stato inviato. Controlla lo storico nel tuo profilo", payload: { redirect: false } };
			} else {
				return { action: 'new', success: true, message: "Benvenuto! L'ordine è stato inviato. Tra poco verrai reindirizzato sul tuo profilo.", payload: { redirect: true } };
			}

		} catch (error) {
			console.error('Error creating new order:', error);
			return fail(400, { action: 'new', success: false, message: 'Error new order' });
		}
	},

	applyDiscount: async ({ request, fetch, locals }) => {
		const formData = await request.formData();
		const discountCode = formData.get('discountCode').toString().toLowerCase().trim();
		const cart = formData.get('cart') as string;
		const subTotal = formData.get('subTotal') as string;
		const discountList = formData.get('discountList') as string;
		const originalTotal = Number(subTotal) || 0;
		const discountArray: string[] = JSON.parse(discountList || '[]').map(item => item.code);
		const cartArray: CartItem[] = JSON.parse(cart || '[]');

		try {
			const discountFetch = (discountCodes: string[]) => fetch(`${BASE_URL}/api/mongo/find`, {
				method: 'POST',
				body: JSON.stringify({
					apiKey: APIKEY,
					schema: 'discount',
					query: { code: { $in: discountCodes } },
					projection: { _id: 0, password: 0 },
					sort: { createdAt: -1 },
					limit: 1000,
					skip: 0
				}),
				headers: {
					'Content-Type': 'application/json'
				}
			});

			// let cartArray: CartItem[] = [];
			// try {
			// 	cartArray = JSON.parse(cart || '[]');
			// } catch {
			// 	return fail(400, { action: 'applyDiscount', success: false, message: 'Cart invalido' });
			// }

			if (!discountCode?.trim()) {
				return fail(400, {
					action: 'applyDiscount',
					success: false,
					message: 'Codice sconto richiesto'
				});
			}

			if (discountArray.includes(discountCode)) {
				return fail(400, {
					action: 'applyDiscount',
					success: false,
					message: 'Sconto già applicato'
				});
			}


			// Fetch all discounts from database that match new array
			const newDiscountArray = [...discountArray, discountCode];
			const discountRes = await discountFetch(newDiscountArray);
			const discountGroup: DiscountItem[] = await discountRes.json();
			// console.log('newDiscountArray', newDiscountArray);
			// console.log('discountGroup', discountGroup);

			// Find the specific discount being applied
			const discountItem = discountGroup.find((item: DiscountItem) => item.code === discountCode);

			if (!discountItem) {
				return fail(400, {
					action: 'applyDiscount',
					success: false,
					message: 'Codice sconto non trovato'
				});
			}

			if (discountItem.status === 'disabled') {
				return fail(400, {
					action: 'applyDiscount',
					success: false,
					message: 'Sconto non attivo'
				});
			}


			// check: Prevent more than one 'referral' discount
			const countReferral = discountGroup.filter(d => d.selectedApplicability === 'referral').length;
			if (discountItem.selectedApplicability === 'referral' && countReferral > 1) {
				return fail(400, {
					action: 'applyDiscount',
					success: false,
					message: 'È possibile applicare un solo sconto Formatore.'
				});
			}
			const countRiflessologo = discountGroup.filter(d => d.selectedApplicability === 'riflessologo').length;
			if (discountItem.selectedApplicability === 'riflessologo' && countRiflessologo > 1) {
				return fail(400, {
					action: 'applyDiscount',
					success: false,
					message: 'È possibile applicare un solo sconto Riflessologo.'
				});
			}

			// check for "referral" and "riflessologo" conflict
			const isReferralDiscount = discountItem.selectedApplicability === 'referral';
			const isRiflessologoDiscount = discountItem.selectedApplicability === 'riflessologo';

			const existReferralDiscountInGroup = discountGroup.some(d => d.selectedApplicability === 'referral');
			const existRiflessologoDiscountInGroup = discountGroup.some(d => d.selectedApplicability === 'riflessologo');

			if (existReferralDiscountInGroup && existRiflessologoDiscountInGroup) {
				return fail(400, {
					action: 'applyDiscount',
					success: false,
					message: 'È possibile applicare un solo sconto Formatore.'
				});
			}

			const validateDiscountApplicability = (
				discount: DiscountItem,
				user: any,
				cartArray: CartItem[]
			): boolean => {
				const { selectedApplicability } = discount;

				switch (selectedApplicability) {
					case 'email':
						return discount.email === user?.email;

					case 'membershipLevel':
						return discount.membershipLevel === user?.membership?.membershipLevel;

					case 'prodId':
						return cartArray.some(item => item.prodId === discount.prodId);

					case 'layoutId':
						return cartArray.some(item => item.layoutView?.layoutId === discount.layoutId);

					case 'referral':
						return true;

					case 'riflessologo':
						//console.log('isRiflessologo:', user.isRiflessologo);
						return user?.isRiflessologo === true;

					default:
						return false;
				}
			};
			if (!validateDiscountApplicability(discountItem, locals.user, cartArray)) {
				return fail(400, {
					action: 'applyDiscount',
					success: false,
					message: 'Sconto non applicabile'
				});
			}

			// Validazione quantità per sconti qty
			if (discountItem.selectedApplicability === 'prodId' && discountItem.qty && discountItem.qty > 1) {
				const productInCart = cartArray.find(item => item.prodId === discountItem.prodId);
				const currentQty = productInCart?.orderQuantity || 0;

				if (currentQty < discountItem.qty) {
					return fail(400, {
						action: 'applyDiscount',
						success: false,
						message: `Quantità insufficiente. Servono almeno ${discountItem.qty} pezzi per applicare questo sconto (attualmente: ${currentQty})`
					});
				}
			}

			// Calculate all discounts
			const discountApplied = () => {
				return discountGroup.map(discount => ({
					code: discount.code,
					//type: discount.type,
					totalDiscount: calculateItemDiscount(discount, cartArray, originalTotal)
				}));
			};

			return {
				action: 'applyDiscount',
				success: true,
				message: 'Sconto applicato con successo',
				payload: {
					discountApplied: discountApplied(),
					discountId: discountItem.discountId
				}
			};

		} catch (error) {
			console.error('Error applying discount:', error);
			return fail(500, {
				action: 'applyDiscount',
				success: false,
				message: 'Errore durante l\'applicazione dello sconto'
			});
		}
	},

	removeDiscount: async ({ request, fetch, locals }) => {
		const discountFetch = (discountCodes: string[]) => fetch(`${BASE_URL}/api/mongo/find`, {
			method: 'POST',
			body: JSON.stringify({
				apiKey: APIKEY,
				schema: 'discount',
				query: { code: { $in: discountCodes } },
				projection: { _id: 0, password: 0 },
				sort: { createdAt: -1 },
				limit: 1000,
				skip: 0
			}),
			headers: {
				'Content-Type': 'application/json'
			}
		});
		try {
			const formData = await request.formData();
			const removeCode = formData.get('removeCode').toString().toLowerCase().trim();
			const subTotal = formData.get('subTotal') as string;
			const cart = formData.get('cart') as string;
			const discountList = formData.get('discountList') as string;
			const originalTotal = Number(subTotal) || 0;
			const cartArray: CartItem[] = JSON.parse(cart || '[]');
			let discountArray: string[] = JSON.parse(discountList || '[]').map(item => item.code);

			if (!removeCode?.trim()) {
				return fail(400, {
					action: 'removeDiscount',
					success: false,
					message: 'Codice sconto richiesto'
				});
			}

			// Remove the discount code from array
			discountArray = discountArray.filter(code => code !== removeCode);

			// IF no discounts remain, return empty result
			if (discountArray.length === 0) {
				return {
					action: 'removeDiscount',
					success: true,
					message: 'Sconto rimosso con successo',
					payload: {
						discountApplied: [],
					}
				};
			}

			// Fetch remaining discounts from database
			const discountRes = await discountFetch(discountArray);
			const discountGroup: DiscountItem[] = await discountRes.json();

			// Calculate remaining discounts
			const discountApplied = () => {
				return discountGroup.map(discount => ({
					code: discount.code,
					totalDiscount: calculateItemDiscount(discount, cartArray, originalTotal)
				}));
			};

			return {
				action: 'removeDiscount',
				success: true,
				message: 'Sconto rimosso con successo',
				payload: {
					discountApplied: discountApplied(),
				}
			};

		} catch (error) {
			console.error('Error removing discount:', error);
			return fail(500, {
				action: 'removeDiscount',
				success: false,
				message: 'Errore durante la rimozione dello sconto'
			});
		}
	}

} satisfies Actions;