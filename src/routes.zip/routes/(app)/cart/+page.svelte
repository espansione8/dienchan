<script lang="ts">
	import type { ActionResult } from '@sveltejs/kit';
	import { goto, invalidateAll } from '$app/navigation';
	import { onMount } from 'svelte';
	import { enhance } from '$app/forms';
	import { Image } from '@unpic/svelte';
	import Modal from '$lib/components/Modal.svelte';
	import { tick } from 'svelte';
	import { notification } from '$lib/stores/notifications';
	import { cartProducts, addToCart, removeFromCart, emptyCart } from '$lib/stores/cart';
	import Loader from '$lib/components/Loader.svelte';
	import { country_list, province } from '$lib/stores/arrays';
	import { imgCheck } from '$lib/tools/tools';
	import { loadStripe, type Stripe, type StripeElements } from '@stripe/stripe-js';
	import {
		Settings,
		X,
		Check,
		Lock,
		Tags,
		Boxes,
		ShoppingCart,
		CircleX,
		Info,
		Trash2,
		CreditCard,
		Landmark,
		Pen,
		Mail,
		Phone,
		User,
		MapPin,
		ArrowLeft,
		CircleCheckBig,
		Tag,
		HandCoins,
		Car
	} from 'lucide-svelte';

	const { data } = $props();
	const { userData, auth, stripePublishableKey } = $derived(data);

	let formEl: HTMLFormElement;
	// Stripe state
	let stripe: Stripe | null = $state(null);
	let elements: StripeElements | null = $state(null);
	let cardElement: any;
	let stripeError = $state<string | null>(null);
	// let paymentMethodId = $state<string | null>(null);
	let clientSecret = $state<string | null>(null);
	let paymentIntentId = $state<string | null>(null);

	let password1 = $state('');
	let password2 = $state('');
	let checkPass = $state(false);
	let checkSecondPass = $state(false);

	let formData = $state({
		name: userData?.name || '',
		surname: userData?.surname || '',
		email: userData?.email || '',
		address: userData?.address || '',
		city: userData?.city || '',
		county: userData?.county[0] || 'AG', // provincia
		postalCode: userData?.postalCode || '',
		country: userData?.country || 'Italy',
		phone: userData?.phone || '',
		mobilePhone: userData?.mobilePhone || '',
		paymentType: 'Carta di credito',
		orderNotes: '',
		usePoint: false,
		pointsBalance: userData?.pointsBalance || 0,
		newBalance: 0,
		storePickUp: false,
		differentShippingAddress: false
	});

	let shippingName = $derived(formData.differentShippingAddress == true ? '' : userData?.name);
	let shippingSurname = $derived(formData.differentShippingAddress == true ? '' : userData?.surname);
	let shippingPhone = $derived(formData.differentShippingAddress == true ? '' : userData?.phone);
	let shippingMobilePhone = $derived(formData.differentShippingAddress == true ? '' : userData?.mobilePhone);
	let shippingAddress = $derived(formData.differentShippingAddress == true ? '' : userData?.address);
	let shippingCity = $derived(formData.differentShippingAddress == true ? '' : userData?.city);
	let shippingCounty = $derived(formData.differentShippingAddress == true ? '' : userData?.county[0]);
	let shippingPostalCode = $derived(formData.differentShippingAddress == true ? '' : userData?.postalCode);
	let shippingCountry = $derived(formData.differentShippingAddress == true ? '' : userData?.country);
	// let shippingState = $derived(formData.differentShippingAddress == true ? '' : userData?.state)
	let shippingEmail = $derived(formData.differentShippingAddress == true ? '' : userData?.email);
	// let shippingRegion = $derived(formData.differentShippingAddress == true ? '' : userData?.region)

	let closedInput = $state(true);

	// discount
	let discountCode = $state('');
	let discountList = $state([]);

	// modal
	let currentModal = $state('');
	let openModal = $state(false);
	let modalTitle = $state('');
	let postAction = $state('?/');
	let loading = $state(false);

	// cart
	let cart = $state($cartProducts);
	let subTotal: any = $derived(() => {
		let total = 0;
		$cartProducts.forEach((element: any) => {
			if (element.type == 'course') {
				total += element.layoutView.price * (element.orderQuantity || 1);
			} else {
				total += element.price * (element.orderQuantity || 1);
			}
		});
		return total;
	});

	const calculateDeliveryFee = (subtotal: number) => {
		// Se ritiro in sede, spedizione gratuita
		if (formData.storePickUp) return 0;

		// Se subtotale >= 100€, spedizione gratuita
		if (subtotal >= 100) return 0;

		// Se subtotale o prodotti a costo 0, spedizione gratuita
		const allFree = subtotal === 0 || ($cartProducts.length > 0 && $cartProducts.every((item: any) => item.price === 0));
		if (allFree) return 0;

		// Verifica se nel carrello ci sono SOLO libri
		const onlyBooks = $cartProducts.length > 0 && $cartProducts.every((item: any) => item.category && item.category.includes('Libri'));

		// Se solo libri: 4.5€, altrimenti 9€
		return onlyBooks ? 4.5 : 9;
	};

	let couponDiscount = $derived(() => discountList.reduce((acc, element: any) => acc + (element.totalDiscount || 0), 0));

	let pointsDiscount = $derived(() => {
		if (formData.usePoint) {
			let total = subTotal() + calculateDeliveryFee(subTotal());
			const totalAfterOtherDiscounts = total - couponDiscount();
			// Math.min: The points used as discount cannot exceed the available points
			// Math.max: cannot make the total negative. always minimum 0
			return Math.min(formData.pointsBalance, Math.max(0, totalAfterOtherDiscounts));
		}
		return 0;
	});
	let totalDiscount = $derived(() => couponDiscount() + pointsDiscount());

	//let grandTotal = $derived(subTotal() - totalDiscount());
	let grandTotal = $derived(() => {
		let tempTotal = subTotal() + calculateDeliveryFee(subTotal());
		// let tempTotal = subTotal();
		// if (tempTotal < 100) {
		// 	tempTotal += 9; // Add delivery fee if total is above 100
		// }

		let total = tempTotal - totalDiscount();

		return total;
	});

	const clickPoint = () => {
		formData.usePoint = !formData.usePoint;
		if (formData.usePoint) {
			if (grandTotal() == 0) {
				formData.paymentType = 'Punti';
			} else {
				formData.paymentType = 'Carta di credito';
			}
		}

		// let finalTotal = subTotal();
		// console.log('before pointsBalance', formData.pointsBalance);
		// if (formData.usePoint) {
		// 	if (formData.pointsBalance < subTotal()) {
		// 		finalTotal = subTotal() - formData.pointsBalance;
		// 		formData.pointsBalance = 0;
		// 	} else if (formData.pointsBalance >= grandTotal) {
		// 		finalTotal = 0;
		// 		formData.pointsBalance -= subTotal();
		// 	}
		// 	console.log('finalTotal', finalTotal);
		// 	console.log('formData.pointsBalance', formData.pointsBalance);
		// }
		// return finalTotal;
	};

	let newPointsBalance = $derived(() => {
		if (formData.usePoint) {
			let total = subTotal() + calculateDeliveryFee(subTotal());
			// let total = subTotal();
			// if (total < 100) {
			// 	total += 9; // Add delivery fee if total is above 100
			// }
			const totalAfterOtherDiscounts = total - couponDiscount();
			const pointsUsed = Math.min(formData.pointsBalance, Math.max(0, totalAfterOtherDiscounts));
			return formData.pointsBalance - pointsUsed;
		}
		return formData.pointsBalance;
	});

	const initializeStripe = async () => {
		if (!stripePublishableKey) {
			stripeError = 'La chiave pubblica di Stripe non è disponibile.';
			return;
		}

		try {
			if (!stripe) {
				stripe = await loadStripe(stripePublishableKey);
			}

			if (stripe) {
				if (!elements) {
					elements = stripe.elements();
				}
				cardElement = elements.create('card', {
					hidePostalCode: true,
					style: {
						base: {
							fontSize: '16px',
							color: '#424770',
							'::placeholder': {
								color: '#aab7c4'
							}
						},
						invalid: {
							color: '#9e2146'
						}
					}
				});

				// IMPORTANT: element DOM must be in the HTML
				const cardElementContainer = document.getElementById('card-element');
				if (cardElementContainer) {
					cardElement.mount(cardElementContainer);
					stripeError = null;
					//console.log('Stripe Card Element montato con successo.');
				} else {
					console.error("ERRORE: Elemento '#card-element' non trovato nel DOM per il montaggio di Stripe.");
					stripeError = "Si è verificato un errore durante l'inizializzazione del pagamento. Riprova.";
				}
			} else {
				stripeError = 'Impossibile caricare Stripe. Riprova più tardi.';
			}
		} catch (e: any) {
			console.error("Errore durante l'inizializzazione di Stripe:", e);
			stripeError = `Errore di inizializzazione: ${e.message || 'Errore sconosciuto'}`;
		}
	};

	// const getStripeId = async () => {
	// 	if (formData.paymentType === 'Carta di credito') {
	// 		stripeError = null;

	// 		if (!stripe || !elements || !cardElement) {
	// 			stripeError = 'Stripe non è stato inizializzato correttamente. Riprova.';
	// 			notification.error(stripeError);
	// 			loading = false;
	// 		}

	// 		// get PaymentMethod  Stripe.js
	// 		const { paymentMethod, error } = await stripe.createPaymentMethod({
	// 			type: 'card',
	// 			card: cardElement,
	// 			billing_details: {
	// 				name: `${userData?.name || 'nome'} ${userData?.surname || 'cognome'}`,
	// 				email: userData?.email || 'email@example.com',
	// 				phone: formData.phone,
	// 				address: {
	// 					city: formData.city,
	// 					country: formData.country === 'Italy' ? 'IT' : formData.country,
	// 					line1: formData.address,
	// 					postal_code: formData.postalCode,
	// 					state: formData.county
	// 				}
	// 			}
	// 		});

	// 		if (error) {
	// 			stripeError = error.message;
	// 			notification.error(stripeError);
	// 			console.error('Stripe.js error:', error);
	// 			loading = false;
	// 		}

	// 		if (paymentMethod) {
	// 			paymentMethodId = paymentMethod.id;
	// 			//alert(`paymentMethodId created: ${paymentMethod.id}`);
	// 		} else {
	// 			// Edge case: no error but also no paymentMethod (shouldn't happen with Stripe API)
	// 			stripeError = 'Impossibile creare il metodo di pagamento. Riprova.';
	// 			notification.error(stripeError);
	// 			loading = false;
	// 		}
	// 	}
	// };

	const testPass = () => {
		checkPass = password1.length >= 8;
		checkSecondPass = password1 === password2;
	};

	const testSecondPass = () => {
		checkSecondPass = password1 === password2;
	};

	const onRemoveFromCart = (item: any) => {
		removeFromCart($cartProducts, item);
		discountList = [];
		cart = $cartProducts;
		discountCode = '';
	};

	const updateQuantity = (item: any, increment: boolean) => {
		if (increment) {
			addToCart($cartProducts, item, false);
		} else {
			removeFromCart($cartProducts, item);
		}
		cart = $cartProducts;
		// reset discount
		discountList = [];
		discountCode = '';
	};

	const onEmptyCart = () => {
		emptyCart();
		// reset discounts;
		discountList = [];
		discountCode = '';
		cart = $cartProducts;
		if (cardElement) {
			cardElement.destroy();
			cardElement = null;
			elements = null;
			stripe = null;
			stripeError = null;
			// paymentMethodId = null;
			clientSecret = null;
			paymentIntentId = null;
		}
		initializeStripe();
	};

	const resetFields = () => {
		openModal = false;
		if (!auth) {
			formData.name = '';
			formData.surname = '';
			formData.email = '';
			formData.address = '';
			formData.city = '';
			formData.county = 'AG';
			formData.postalCode = '';
			formData.country = 'Italy';
			formData.phone = '';
			formData.mobilePhone = '';
			formData.paymentType = 'Carta di credito';
			formData.pointsBalance = 0;
		}
		formData.usePoint = false;
		formData.newBalance = 0;
		formData.differentShippingAddress = false;

		modalTitle = '';
		postAction = '?/';
		loading = false;
		formData.storePickUp = false;
	};

	const refresh = () => {
		invalidateAll();
		resetFields();
	};

	const onClickModal = (type: string, item: any) => {
		currentModal = type;
		openModal = true;
		if (type == 'new') {
			postAction = `?/new`;
			modalTitle = 'Riepilogo Ordine';
		}
		// if (type == 'modify') {
		// 	postAction = `?/modify`;
		// 	modalTitle = 'Modifica';
		// }
		// if (type == 'delete') {
		// 	postAction = `?/delete`;
		// 	modalTitle = 'Elimina';
		// }
		// if (type == 'filter') {
		// 	postAction = `?/filter`;
		// 	modalTitle = 'Filtra';
		// }
	};

	const onCloseModal = () => {
		openModal = false;
		//resetFields();
		currentModal = '';
	};

	// NEW: Create PaymentIntent and get client secret
	const createPaymentIntent = async () => {
		if (formData.paymentType !== 'Carta di credito' || clientSecret) {
			return true;
		}

		loading = true;
		stripeError = null;

		try {
			const response = await fetch('?/createPaymentIntent', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				body: new URLSearchParams({
					totalValue: grandTotal().toString(),
					email: formData.email,
					name: formData.name,
					surname: formData.surname
				})
			});
			// const formDataToSend = new FormData();
			// formDataToSend.append('totalValue', subTotal.toString());
			// formDataToSend.append('email', formData.email);
			// formDataToSend.append('name', formData.name);
			// formDataToSend.append('surname', formData.surname);

			// const response = await fetch('?/createPaymentIntent', {
			// 	method: 'POST',
			// 	body: formDataToSend
			// });
			const result = await response.json();
			//console.log('createPaymentIntent result:', result);

			// Check if action was successful
			if (result.type === 'success' && result.data) {
				const dataArray: any[] = JSON.parse(result.data);
				const resSecret = dataArray?.[4];
				const resIntent = dataArray?.[5];
				//console.log(resSecret, resIntent);

				if (resSecret && resIntent) {
					clientSecret = resSecret;
					paymentIntentId = resIntent;
					//console.log('PaymentIntent created:', paymentIntentId);
					loading = false;
					return true;
				} else {
					stripeError = 'Errore durante la creazione del pagamento (1)';
					notification.error(stripeError);
					loading = false;
					return false;
				}
			} else if (result.type === 'failure') {
				stripeError = 'Errore durante la creazione del pagamento (2)';
				notification.error(stripeError);
				loading = false;
				return false;
			} else {
				stripeError = 'Errore durante la creazione del pagamento';
				notification.error(stripeError);
				loading = false;
				return false;
			}
		} catch (error: any) {
			console.error('createPaymentIntent error:', error);
			stripeError = `Errore: ${error.message}`;
			notification.error(stripeError);
			loading = false;
			return false;
		}
	};

	// NEW: Confirm payment with 3DS using Stripe.js
	const confirmPaymentWith3DS = async () => {
		if (formData.paymentType !== 'Carta di credito' || !clientSecret) {
			return true;
		}

		loading = true;
		stripeError = null;

		if (!stripe || !cardElement) {
			stripeError = 'Stripe non è stato inizializzato correttamente. Riprova.';
			notification.error(stripeError);
			loading = false;
			return false;
		}

		try {
			// Use confirmCardPayment which handles 3DS automatically
			const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
				payment_method: {
					card: cardElement,
					billing_details: {
						name: `${formData.name} ${formData.surname}`,
						email: formData.email,
						phone: formData.phone,
						address: {
							city: formData.city,
							country: formData.country === 'Italy' ? 'IT' : formData.country,
							line1: formData.address,
							postal_code: formData.postalCode,
							state: formData.county
						}
					}
				}
			});

			//console.log('3DpaymentIntent', paymentIntent);
			//console.log('error', error);

			if (error) {
				stripeError = error.message;
				notification.error(stripeError || 'Errore durante il pagamento');
				loading = false;
				return false;
			}

			if (paymentIntent && paymentIntent.status === 'succeeded') {
				paymentIntentId = paymentIntent.id;
				//console.log('id', paymentIntent.id, paymentIntentId);
				loading = false;
				return true;
			} else {
				stripeError = `Pagamento non completato: ${paymentIntent?.status || 'unknown'}`;
				notification.error(stripeError);
				loading = false;
				return false;
			}
		} catch (err: any) {
			stripeError = err.message || 'Errore sconosciuto';
			notification.error(stripeError);
			loading = false;
			return false;
		}
	};

	const formSubmit = () => {
		loading = true;
		return async ({ result }: { result: ActionResult }) => {
			//return async ({ result, update }: { result: ActionResult; update: () => Promise<void> }) => {
			await invalidateAll();
			if (result.type === 'success' && result.data) {
				const { action, message, payload } = result.data; // { action, success, message, payload }

				if (action === 'new') {
					onEmptyCart();
					currentModal = 'success';
				}
				if (action === 'applyDiscount' || action === 'removeDiscount') {
					discountList = payload?.discountApplied || [];
					discountCode = '';
				}

				notification.info(message);
				//onCloseModal();
			}
			if (result.type === 'failure') {
				resetFields();
				notification.error(result.data.message || 'Errore carrello');
				discountCode = '';
			}
			if (result.type === 'error') {
				resetFields();
				notification.error(result.error.message || 'Errore ');
				discountCode = '';
			}
			// if (result.type === 'redirect') {
			// 	emptyCart();
			// }
			// 'update()' is called by default by use:enhance
			// call 'await update()' if you need to ensure it completes before further client logic.

			await invalidateAll();
			resetFields();
			loading = false;
		};
	};

	onMount(() => {
		initializeStripe();
	});

	// Handle final submission with payment confirmation
	const handleFinalSubmit = async (event: Event) => {
		//event.preventDefault();
		loading = true;

		// if (!formData.name || !formData.surname || formData.email || !formData.address || !formData.city  || !formData.country || !formData.county) {
		// 	notification.error('Dati mancanti');
		// 		loading = false;
		// 	return;
		// }

		// if (!isCurrentStepValid()) {
		// 	notification.error('Completa tutti i campi richiesti');
		// 	return;
		// }

		// Step 1: Create PaymentIntent if credit card
		if (formData.paymentType === 'Carta di credito' && !clientSecret) {
			const intentCreated = await createPaymentIntent();
			//console.log('FINAL intentCreated', intentCreated, paymentIntentId);
			if (!intentCreated) {
				return;
			}
		}

		// Step 2: Confirm payment with 3DS
		if (formData.paymentType === 'Carta di credito') {
			const paymentConfirmed = await confirmPaymentWith3DS();
			//console.log('FINAL 3DS paymentConfirmed', paymentConfirmed, paymentIntentId);
			if (!paymentConfirmed) {
				return;
			}
		}
		// console.log('FINAL paymentIntentId', paymentIntentId);
		// Step 3: Submit the form
		await tick();

		// let hiddenInput;
		// if (paymentIntentId) {
		// 	console.log('INPUT paymentIntentId', paymentIntentId);
		// 	hiddenInput = document.createElement('input');
		// 	hiddenInput.type = 'hidden';
		// 	hiddenInput.name = 'paymentIntentId';
		// 	hiddenInput.value = paymentIntentId;

		// 	form.appendChild(hiddenInput);
		// }

		//const form = event.target as HTMLFormElement;
		//form.requestSubmit();
		if (formEl) {
			formEl.requestSubmit();
		}
	};
</script>

<svelte:head>
	<title>Carrello</title>
</svelte:head>

<div class="container mx-auto px-4 py-8">
	<div class="flex flex-col lg:flex-row gap-8">
		<!-- Cart Items Section -->
		<div class="w-full lg:w-3/5">
			<div class="bg-white rounded-xl shadow-md overflow-hidden">
				<div class="bg-primary text-primary-content px-6 py-4 flex justify-between items-center">
					<h2 class="text-xl font-bold">Il tuo carrello</h2>
					<span class="badge badge-lg badge-outline font-semibold">{$cartProducts.length} prodotti</span>
				</div>

				{#if $cartProducts.length > 0}
					<div class="p-6">
						<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
							{#each $cartProducts as item}
								<div class="card bg-base-100 border border-base-200 shadow-sm overflow-hidden">
									<div class="flex flex-col h-full">
										<div class="p-4 flex gap-4">
											<div class="w-1/3">
												<div class="aspect-square bg-base-200/30 rounded-lg overflow-hidden flex items-center justify-center">
													<Image
														layout="constrained"
														aspectRatio={1}
														src={imgCheck.single(item.uploadfiles, 'product-primary')}
														alt="product"
														class="h-full w-full object-contain p-2"
													/>
												</div>
											</div>

											<div class="w-2/3">
												<div class="flex justify-between items-start">
													<a href="/product-detail/{item.prodId}" class="hover:text-primary transition-colors">
														<h3 class="text-base font-bold">{item.title}</h3>
													</a>
													<!-- <div class="text-lg font-bold text-primary">€{item.price}</div> -->
												</div>

												<div class="flex items-center gap-2 mt-2 text-xs">
													<Tags size={14} class="text-primary flex-shrink-0" />
													<span class="font-medium">{item.category?.[0] || 'Categoria'}</span>
												</div>

												<div class="flex items-center gap-1 mt-2 text-xs">
													{#if item.stockQty < 1}
														<div class="text-error flex items-center gap-1">
															<Boxes size={14} />
															<span>Esaurito</span>
														</div>
													{:else}
														<div class="text-success flex items-center gap-1">
															<Boxes size={14} />
															<span>{item.stockQty} disponibili</span>
														</div>
													{/if}
												</div>
												<div class="flex items-center gap-1 mt-1 text-xs">
													<div class="text-lg font-bold text-primary">€ {item.price} pz</div>
												</div>
											</div>
										</div>

										<div class="mt-auto border-t border-base-200 p-4 flex items-center justify-between">
											<div class="flex items-center gap-2">
												<button class="btn btn-xs btn-outline btn-error" onclick={() => onRemoveFromCart(item)}>
													<Trash2 size={14} />
													Rimuovi
												</button>

												<a href="/product-detail/{item.prodId}" class="btn btn-xs btn-outline">
													<Info size={14} />
													Dettagli
												</a>
											</div>

											<div class="join">
												<button class="join-item btn btn-xs" onclick={() => updateQuantity(item, false)} disabled={item.orderQuantity <= 1}>-</button>
												<input
													type="text"
													class="join-item input input-xs input-bordered w-10 text-center"
													value={item.orderQuantity || 1}
													readonly
												/>
												<button class="join-item btn btn-xs" onclick={() => updateQuantity(item, true)} disabled={item.orderQuantity >= item.stockQty}
													>+</button
												>
											</div>
										</div>
									</div>
								</div>
							{/each}
						</div>

						<div class="flex justify-between pt-6">
							<button class="btn btn-outline btn-error" onclick={() => onEmptyCart()}>
								<Trash2 size={16} />
								Svuota carrello
							</button>

							<a href="/product-shop" class="btn btn-outline">
								<ArrowLeft size={16} />
								Continua lo shopping
							</a>
						</div>
					</div>
				{:else}
					<div class="p-16 flex flex-col items-center justify-center text-center">
						<div class="w-20 h-20 bg-base-200 rounded-full flex items-center justify-center mb-4">
							<ShoppingCart size={32} class="text-base-content/50" />
						</div>
						<h3 class="text-xl font-bold mb-2">Il tuo carrello è vuoto</h3>
						<p class="text-base-content/70 mb-6">Aggiungi alcuni prodotti per iniziare lo shopping</p>
						<a href="/product-shop" class="btn btn-primary"> Inizia lo shopping </a>
					</div>
				{/if}
			</div>
		</div>

		<!-- Order Summary Section -->
		<div class="w-full lg:w-2/5 space-y-6">
			<!-- {#if $cartProducts.length > 0} -->
			<!-- User Profile -->
			<div class="bg-white rounded-xl shadow-md overflow-hidden">
				<div class="bg-primary text-primary-content px-6 py-4 flex justify-between items-center">
					<h2 class="text-xl font-bold">
						{#if auth}
							Profilo
						{:else}
							Prima iscrizione
						{/if}
					</h2>

					{#if auth}
						<a href="/profile-area" class="btn btn-sm btn-outline">
							<Settings size={16} /> Modifica
						</a>
					{/if}
				</div>

				<div class="p-6">
					<form method="POST" use:enhance={formSubmit}>
						<div class="space-y-4">
							<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
								<!-- Nome -->
								<div class="form-control w-full">
									<label for="Name" class="label">
										<span class="label-text font-medium">Nome</span>
									</label>
									<input
										id="Name"
										name="name"
										type="text"
										class="input input-bordered w-full"
										placeholder="Inserisci il tuo nome"
										required
										readonly={closedInput}
										bind:value={formData.name}
									/>
								</div>

								<!-- Cognome -->
								<div class="form-control w-full">
									<label for="Surname" class="label">
										<span class="label-text font-medium">Cognome</span>
									</label>
									<input
										id="Surname"
										name="surname"
										type="text"
										class="input input-bordered w-full"
										placeholder="Inserisci il tuo cognome"
										required
										readonly={closedInput}
										bind:value={formData.surname}
									/>
								</div>
							</div>

							<!-- Email -->
							<div class="form-control w-full">
								<label for="Email" class="label">
									<span class="label-text font-medium">Email</span>
								</label>
								<div class="input input-bordered flex items-center gap-2 pr-2">
									<Mail size={18} class="ml-2" />
									<input
										id="Email"
										name="email"
										type="email"
										class="flex-1 outline-none bg-transparent"
										placeholder="esempio@email.com"
										required
										readonly={closedInput}
										bind:value={formData.email}
									/>
								</div>
							</div>

							<!-- Password & Confirm -->
							<!-- {#if !auth}
								<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
									<div class="form-control w-full">
										<label for="password" class="label">
											<span class="label-text font-medium">
												Password <span class="text-xs"> (Almeno 8 caratteri) </span>
											</span>
										</label>
										<div class="input input-bordered flex items-center gap-2 pr-2">
											<Lock size={18} class="ml-2" color={checkPass ? 'green' : 'currentColor'} />
											<input
												class="flex-1 outline-none bg-transparent"
												id="password"
												name="password1"
												type="password"
												placeholder="Inserisci la password"
												aria-label="Password"
												bind:value={password1}
												minlength="8"
												required={!auth}
												oninput={testPass}
											/>
										</div>
									</div>

									<div class="form-control w-full">
										<label for="password2" class="label">
											<span class="label-text font-medium">
												Conferma password {#if !checkSecondPass && password2}
													<span class="text-error text-xs"> (non corrispondente) </span>
												{/if}
											</span>
										</label>
										<div class="input input-bordered flex items-center gap-2 pr-2">
											<Lock size={18} class="ml-2" color={checkSecondPass && checkPass ? 'green' : password2 ? 'red' : 'currentColor'} />
											<input
												class="flex-1 outline-none bg-transparent"
												id="password2"
												name="password2"
												type="password"
												placeholder="Conferma la password"
												bind:value={password2}
												minlength="8"
												required={!auth}
												oninput={testSecondPass}
											/>
										</div>
									</div>
								</div>
							{/if} -->

							<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
								<!-- Telefono -->
								<div class="form-control w-full">
									<label for="telefono" class="label">
										<span class="label-text font-medium">Telefono</span>
									</label>
									<div class="input input-bordered flex items-center gap-2 pr-2">
										<Phone size={18} class="ml-2" />
										<input
											id="telefono"
											name="phone"
											type="tel"
											class="flex-1 outline-none bg-transparent"
											placeholder="+39 01234567"
											readonly={closedInput}
											bind:value={formData.phone}
										/>
									</div>
								</div>

								<!-- Cellulare -->
								<div class="form-control w-full">
									<label for="cellulare" class="label">
										<span class="label-text font-medium">
											Cellulare <span class="text-xs"> (richiesto) </span>
										</span>
									</label>
									<div class="input input-bordered flex items-center gap-2 pr-2">
										<Phone size={18} class="ml-2" />
										<input
											id="cellulare"
											name="mobilePhone"
											type="tel"
											class="flex-1 outline-none bg-transparent"
											placeholder="+39 3331234567"
											required
											readonly={closedInput}
											bind:value={formData.mobilePhone}
										/>
									</div>
								</div>
							</div>

							<div class="divider my-2">Indirizzo</div>

							<!-- Indirizzo -->
							<div class="form-control w-full">
								<label for="address" class="label">
									<span class="label-text font-medium">Indirizzo</span>
								</label>
								<div class="input input-bordered flex items-center gap-2 pr-2">
									<MapPin size={18} class="ml-2" />
									<input
										id="address"
										name="address"
										type="text"
										class="flex-1 outline-none bg-transparent"
										placeholder="Via/Piazza, numero civico"
										required
										readonly={closedInput}
										bind:value={formData.address}
									/>
								</div>
							</div>

							<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
								<!-- Città -->
								<div class="form-control w-full">
									<label for="city" class="label">
										<span class="label-text font-medium">Città</span>
									</label>
									<input
										id="city"
										name="city"
										type="text"
										class="input input-bordered w-full"
										placeholder="Inserisci la città"
										required
										readonly={closedInput}
										bind:value={formData.city}
									/>
								</div>

								<!-- CAP -->
								<div class="form-control w-full">
									<label for="postalcode" class="label">
										<span class="label-text font-medium">CAP</span>
									</label>
									<input
										id="postalCode"
										name="postalCode"
										type="text"
										class="input input-bordered w-full"
										placeholder="12345"
										required
										readonly={closedInput}
										bind:value={formData.postalCode}
									/>
								</div>
							</div>

							<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
								<!-- Provincia -->
								<div class="form-control w-full">
									<label for="state" class="label">
										<span class="label-text font-medium">Provincia</span>
									</label>
									<!-- bindo la prima provincia considerata come quella più vicina alla persona -->
									<select
										id="county"
										class="select select-bordered w-full"
										name="county"
										required
										disabled={closedInput}
										bind:value={formData.county}
									>
										<option value="" disabled>Seleziona provincia</option>
										{#each $province as provincia, i}
											{#if provincia.title !== 'Online'}
												<option value={provincia.title}>
													{provincia.title} ({provincia.region})
												</option>
											{/if}
										{/each}
									</select>
									{#if closedInput}
										<input type="hidden" name="county" value={formData.county} />
									{/if}
								</div>

								<!-- Nazione -->
								<div class="form-control w-full">
									<label for="country" class="label">
										<span class="label-text font-medium">Nazione</span>
									</label>
									<select
										id="country"
										class="select select-bordered w-full"
										name="country"
										required
										disabled={closedInput}
										bind:value={formData.country}
									>
										<option value="" disabled>Seleziona nazione</option>
										{#each $country_list as countryItem}
											<option value={countryItem}>
												{countryItem}
											</option>
										{/each}
									</select>
									{#if closedInput}
										<input type="hidden" name="country" value={formData.country} />
									{/if}
								</div>
							</div>

							<!-- Pick up -->
							<div class="form-control">
								<label class="label cursor-pointer justify-start gap-2">
									<input
										type="checkbox"
										class="checkbox checkbox-primary"
										bind:checked={formData.storePickUp}
										onchange={() => (formData.differentShippingAddress = false)}
									/>
									<span class="label-text text-base font-medium">Ritiro in sede (Spedizione gratuita) </span>
								</label>
							</div>
							<!-- {#if !formData.usePoint && formData.pointsBalance >= grandTotal() && $cartProducts.length > 0} -->

							<!-- Checkbox per indirizzo di spedizione diverso -->
							{#if !formData.storePickUp}
								<div class="form-control">
									<label class="label cursor-pointer justify-start gap-2">
										<input type="checkbox" class="checkbox checkbox-primary" bind:checked={formData.differentShippingAddress} />
										<span class="label-text text-base font-medium">L'indirizzo di spedizione è diverso da quello di fatturazione</span>
									</label>
								</div>
								<!-- Sezione indirizzo di spedizione (mostrata solo se il checkbox è selezionato) -->
								{#if formData.differentShippingAddress}
									<div class="space-y-4 bg-base-100 p-4 rounded-lg border">
										<div class="divider my-2">Indirizzo di Spedizione</div>

										<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
											<!-- Nome Spedizione -->
											<div class="form-control w-full">
												<label for="shippingName" class="label">
													<span class="label-text font-medium">Nome</span>
												</label>
												<input
													id="shippingName"
													name="shippingName"
													type="text"
													class="input input-bordered w-full"
													placeholder="Inserisci il nome"
													required={formData.differentShippingAddress}
													bind:value={shippingName}
												/>
											</div>

											<!-- Cognome Spedizione -->
											<div class="form-control w-full">
												<label for="shippingSurname" class="label">
													<span class="label-text font-medium">Cognome</span>
												</label>
												<input
													id="shippingSurname"
													name="shippingSurname"
													type="text"
													class="input input-bordered w-full"
													placeholder="Inserisci il cognome"
													required={formData.differentShippingAddress}
													bind:value={shippingSurname}
												/>
											</div>
										</div>

										<!-- Email Spedizione -->
										<div class="form-control w-full">
											<label for="shippingEmail" class="label">
												<span class="label-text font-medium">Email</span>
											</label>
											<div class="input input-bordered flex items-center gap-2 pr-2">
												<Mail size={18} class="ml-2" />
												<input
													id="shippingEmail"
													name="shippingEmail"
													type="email"
													class="flex-1 outline-none bg-transparent"
													placeholder="Inserisci una mail valida"
													required={formData.differentShippingAddress}
													bind:value={shippingEmail}
												/>
											</div>
										</div>

										<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
											<!-- Telefono Spedizione -->
											<div class="form-control w-full">
												<label for="shippingPhone" class="label">
													<span class="label-text font-medium">Telefono</span>
												</label>
												<div class="input input-bordered flex items-center gap-2 pr-2">
													<Phone size={18} class="ml-2" />
													<input
														id="shippingPhone"
														name="shippingPhone"
														type="tel"
														class="flex-1 outline-none bg-transparent"
														placeholder="Es: +39 01234567"
														bind:value={shippingPhone}
													/>
												</div>
											</div>

											<!-- Cellulare Spedizione -->
											<div class="form-control w-full">
												<label for="shippingMobilePhone" class="label">
													<span class="label-text font-medium">
														Cellulare <span class="text-xs"> (richiesto) </span>
													</span>
												</label>
												<div class="input input-bordered flex items-center gap-2 pr-2">
													<Phone size={18} class="ml-2" />
													<input
														id="shippingMobilePhone"
														name="shippingMobilePhone"
														type="tel"
														class="flex-1 outline-none bg-transparent"
														placeholder="Es: +39 3331234567"
														required={formData.differentShippingAddress}
														bind:value={shippingMobilePhone}
													/>
												</div>
											</div>
										</div>

										<!-- Indirizzo Spedizione -->
										<div class="form-control w-full">
											<label for="shippingAddress" class="label">
												<span class="label-text font-medium">Indirizzo</span>
											</label>
											<div class="input input-bordered flex items-center gap-2 pr-2">
												<MapPin size={18} class="ml-2" />
												<input
													id="shippingAddress"
													name="shippingAddress"
													type="text"
													class="flex-1 outline-none bg-transparent"
													placeholder="Es: Via/Piazza, numero civico"
													required={formData.differentShippingAddress}
													bind:value={shippingAddress}
												/>
											</div>
										</div>

										<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
											<!-- Città Spedizione -->
											<div class="form-control w-full">
												<label for="shippingCity" class="label">
													<span class="label-text font-medium">Città</span>
												</label>
												<input
													id="shippingCity"
													name="shippingCity"
													type="text"
													class="input input-bordered w-full"
													placeholder="Inserisci la città"
													required={formData.differentShippingAddress}
													bind:value={shippingCity}
												/>
											</div>

											<!-- CAP Spedizione -->
											<div class="form-control w-full">
												<label for="shippingPostalCode" class="label">
													<span class="label-text font-medium">CAP</span>
												</label>
												<input
													id="shippingPostalCode"
													name="shippingPostalCode"
													type="text"
													class="input input-bordered w-full"
													placeholder="Es: 34754"
													required={formData.differentShippingAddress}
													bind:value={shippingPostalCode}
												/>
											</div>
										</div>

										<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
											<!-- Provincia Spedizione -->
											<div class="form-control w-full">
												<label for="shippingCounty" class="label">
													<span class="label-text font-medium">Provincia</span>
												</label>
												<select
													id="shippingCounty"
													class="select select-bordered w-full"
													name="shippingCounty"
													required={formData.differentShippingAddress}
													bind:value={shippingCounty}
												>
													<option value="" disabled>Seleziona provincia</option>
													{#each $province as provincia, i}
														{#if provincia.title !== 'Online'}
															<option value={provincia.title}>
																{provincia.title} ({provincia.region})
															</option>
														{/if}
													{/each}
												</select>
												<!-- {#if closedInput}
													<input type="hidden" name="shippingCounty" value={formData.shippingCounty} />
												{/if} -->
											</div>

											<!-- Nazione Spedizione -->
											<div class="form-control w-full">
												<label for="shippingCountry" class="label">
													<span class="label-text font-medium">Nazione</span>
												</label>
												<select
													id="shippingCountry"
													class="select select-bordered w-full"
													name="shippingCountry"
													required={formData.differentShippingAddress}
													bind:value={shippingCountry}
												>
													<option value="" disabled>Seleziona nazione</option>
													{#each $country_list as countryItem}
														<option value={countryItem}>
															{countryItem}
														</option>
													{/each}
												</select>
												<!-- {#if closedInput}
													<input type="hidden" name="shippingCountry" value={formData.shippingCountry} />
												{/if} -->
											</div>
										</div>
									</div>
								{/if}
							{/if}

							{#if grandTotal() > 0}
								<div class="divider my-2 font-medium text-primary">Metodo di Pagamento</div>
								<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
									<!-- <div class="grid grid-cols-1 md:grid-cols-3 gap-4"> -->
									<div class="form-control w-full">
										<label
											class="card bg-base-100 border-2 hover:border-primary hover:bg-base-200 cursor-pointer transition-all p-4 flex flex-col items-center justify-center gap-2"
											class:border-primary={formData.paymentType === 'Bonifico bancario'}
											class:bg-base-200={formData.paymentType === 'Bonifico bancario'}
										>
											<input type="radio" name="payment" value="Bonifico bancario" class="hidden" bind:group={formData.paymentType} />
											<Landmark class="h-8 w-8 text-primary" />
											<span class="text-center font-medium">Bonifico bancario</span>
										</label>
									</div>

									<div class="form-control w-full">
										<label
											class="card bg-base-100 border-2 hover:border-primary hover:bg-base-200 cursor-pointer transition-all p-4 flex flex-col items-center justify-center gap-2"
											class:border-primary={formData.paymentType === 'Carta di credito'}
											class:bg-base-200={formData.paymentType === 'Carta di credito'}
										>
											<input type="radio" name="payment" value="Carta di credito" class="hidden" bind:group={formData.paymentType} />
											<CreditCard class="h-8 w-8 text-primary" />
											<span class="text-center font-medium">Carta di credito</span>
										</label>
									</div>
								</div>
								<!-- {/if} -->

								<div class="card bg-base-100 shadow-xl p-6" class:hidden={formData.paymentType !== 'Carta di credito'}>
									<h3 class="text-xl font-semibold mb-4">Informazioni sulla carta di credito</h3>
									<div class="form-control">
										<div id="card-element" class="border border-base-300 p-3 rounded-md"></div>
										{#if stripeError}
											<p class="text-error text-sm mt-2">{stripeError}</p>
										{/if}
									</div>
									<p class="text-sm text-gray-500 mt-2">
										<Lock size={14} class="inline-block mr-1" /> Le tue informazioni di pagamento sono protette e crittografate con 3D Secure.
									</p>
									<div class="alert alert-info mt-4">
										<Lock size={14} class="inline-block mr-1" />
										<span
											>Il pagamento sarà elaborato con 3D Secure per la massima sicurezza. Potresti essere reindirizzato alla tua banca per
											l'autenticazione.</span
										>
									</div>
								</div>

								<!-- <div class="card bg-base-100 shadow-xl p-6 w-full" class:hidden={formData.paymentType !== 'Carta di credito'}>
									<h3 class="text-xl font-semibold mb-4">Informazioni sulla carta di credito</h3>
									<div class="form-control">
										<div id="card-element" class="border border-base-300 p-3 rounded-md"></div>
										{#if stripeError}
											<p class="text-error text-sm mt-2">{stripeError}</p>
										{/if}
									</div>
									<p class="text-sm text-gray-500 mt-2">
										<Lock size={14} class="inline-block mr-1" /> Le tue informazioni di pagamento sono protette.
									</p>
									{#if !paymentMethodId}
										<button type="button" class="btn btn-info mt-4" onclick={() => getStripeId()}>VERIFICA CARTA </button>
									{:else}
										<div class="btn btn-primary mt-4">CARTA OK <CircleCheckBig /></div>
									{/if}
								</div> -->
								{#if formData.paymentType === 'Bonifico bancario' && grandTotal() > 0}
									<div class="card bg-base-100 shadow-xl p-6">
										<h3 class="text-xl font-semibold mb-4">Dettagli Bonifico Bancario</h3>
										<p>Effettua un bonifico bancario alle seguenti coordinate:</p>
										<p><strong>IBAN:</strong> IT93 R076 0111 5000 0102 3646 647</p>
										<p><strong>BIC/SWIFT:</strong> BPPIITRRXXX</p>
										<p><strong>INTESTATO A:</strong> ASSOCIAZIONE DIEN CHAN BUI QUOC CHAU Italia</p>
										<p>VIA TICINO 12F, 25015, DESENZANO DEL GARDA, BRESCIA</p>
										<br />
										<p>
											Si prega di includere il tuo ID ordine nella causale del bonifico. Il tuo ordine sarà elaborato dopo la conferma del pagamento.
										</p>
									</div>
								{:else if formData.paymentType === 'Bonifico bancario' && grandTotal() === 0 && formData.usePoint}
									<div class="card bg-base-100 shadow-xl p-6">
										<h3 class="text-xl font-semibold mb-4">Pagamento con punti: {pointsDiscount()}</h3>
									</div>
								{/if}
							{/if}
						</div>
					</form>
				</div>
			</div>

			<!-- Order Summary -->
			<div class="bg-white rounded-xl shadow-md overflow-hidden">
				<div class="bg-primary text-primary-content px-6 py-4">
					<h2 class="text-xl font-bold">Riepilogo ordine</h2>
				</div>

				<div class="p-6 space-y-4">
					<div class="flex justify-between">
						<span>Carrello</span>
						<span>€ {subTotal().toFixed(2)}</span>
					</div>
					{#if $cartProducts.length > 0}
						<div class="flex justify-between text-success">
							<span>Spedizione</span>
							<!-- <span>{subTotal() < 100 ? '€ 9' : 'gratuita'}</span> -->
							<span>
								{formData.storePickUp ? '€ 0.00 Ritiro in sede' : `€ ${calculateDeliveryFee(subTotal()).toFixed(2)}`}
							</span>
						</div>
					{/if}

					<!-- {#if discountList.length > 0 || formData.usePoint} -->
					{#if totalDiscount() > 0}
						<div class="flex justify-between text-success">
							<span>Sconto</span>
							<span>- € {totalDiscount().toFixed(2)}</span>
						</div>
					{/if}

					<div class="divider my-2"></div>

					<div class="flex justify-between font-bold text-lg">
						<span>Totale</span>
						<span class="text-primary"
							>{#if $cartProducts.length > 0}
								€ {Math.max(0, grandTotal()).toFixed(2)}
							{/if}</span
						>
					</div>

					<!-- Discount Code -->
					<div class="pt-4">
						<form method="POST" action="?/applyDiscount" use:enhance={formSubmit}>
							<label class="form-control w-full">
								<div class="label">
									<span class="label-text font-medium">Codice sconto</span>
								</div>
								<div class="flex gap-2">
									<input
										type="text"
										id="discountCode"
										name="discountCode"
										placeholder="Inserisci il codice"
										class="input input-bordered w-full"
										bind:value={discountCode}
										disabled={loading || $cartProducts.length < 1}
									/>
									<input type="hidden" name="cart" value={JSON.stringify($cartProducts)} />
									<input type="hidden" name="subTotal" value={subTotal()} />
									<input type="hidden" name="discountList" value={JSON.stringify(discountList)} />
									<button type="submit" class="btn btn-primary" disabled={!discountCode || loading}>
										{#if loading}
											<span class="loading loading-spinner loading-sm text-primary"></span>
										{:else}
											Applica
										{/if}
									</button>
								</div>
							</label>
						</form>

						{#if discountList.length > 0}
							<form method="POST" action="?/removeDiscount" use:enhance={formSubmit}>
								<div class="flex flex-wrap gap-2 mt-3">
									{#each discountList as badgeCode, i}
										<div class="badge badge-lg bg-primary/10 text-primary gap-2">
											<Tag size={14} />
											{badgeCode.code}
											<input type="hidden" name="cart" value={JSON.stringify($cartProducts)} />
											<input type="hidden" name="subTotal" value={subTotal()} />
											<input type="hidden" name="discountList" value={JSON.stringify(discountList)} />
											<input type="hidden" name="removeCode" value={badgeCode.code} />
											<button type="submit" name="removeCode" class="btn btn-xs btn-circle btn-ghost" disabled={loading}>
												<X size={14} />
											</button>
										</div>
									{/each}
								</div>
							</form>
						{/if}
					</div>
					<div>
						<label class="label cursor-pointer justify-start gap-2">
							<input
								type="checkbox"
								checked={formData.usePoint}
								class="checkbox"
								onclick={() => clickPoint()}
								disabled={formData.pointsBalance < 1}
							/>
							<span class="label-text">Spendi saldo punti {formData.usePoint ? `(${Math.round(newPointsBalance())} punti rimasti)` : ''}</span>
						</label>
					</div>
					<button
						class="btn btn-primary w-full mt-4"
						onclick={() => onClickModal(discountList.length === 0 ? 'rememberCoupon' : 'new', null)}
						disabled={$cartProducts.length === 0}
					>
						Procedi al checkout
					</button>
				</div>
			</div>
			<!-- {/if} -->
		</div>
	</div>
</div>

{#if currentModal == 'new'}
	<Modal isOpen={openModal} header={modalTitle} cssClass="max-w-3xl p-6">
		<button class="btn btn-sm btn-circle btn-error absolute right-2 top-2" onclick={onCloseModal}>✕</button>
		{#if loading}
			<Loader />
		{/if}
		<div class="">
			<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 mt-4">
				<div class="space-y-4">
					{#if formData.differentShippingAddress}
						<h4 class="font-medium text-primary">Informazioni di Fatturazione</h4>
					{:else}
						<h4 class="font-medium text-primary">Informazioni di Fatturazione e Spedizione</h4>
					{/if}
					<div class="grid grid-cols-2 gap-2">
						<div>
							<p class="text-sm text-base-content/70">Nome</p>
							<p class="font-medium">{formData.name}</p>
						</div>
						<div>
							<p class="text-sm text-base-content/70">Cognome</p>
							<p class="font-medium">{formData.surname}</p>
						</div>
						<div class="col-span-2">
							<p class="text-sm text-base-content/70">Email</p>
							<p class="font-medium">{formData.email}</p>
						</div>
						<div>
							<p class="text-sm text-base-content/70">Telefono</p>
							<p class="font-medium">{formData.phone || 'Non specificato'}</p>
						</div>
						<div>
							<p class="text-sm text-base-content/70">Cellulare</p>
							<p class="font-medium">{formData.mobilePhone}</p>
						</div>
					</div>
				</div>

				<div class="space-y-4">
					<!-- <h4 class="font-medium text-primary">Indirizzo di Spedizione</h4> -->
					<div class="font-medium text-primary invisible">Placeholder</div>
					<div class="grid grid-cols-2 gap-2">
						<div class="col-span-2">
							<p class="text-sm text-base-content/70">Indirizzo</p>
							<p class="font-medium">{formData.address}</p>
						</div>
						<div>
							<p class="text-sm text-base-content/70">Città</p>
							<p class="font-medium">{formData.city}</p>
						</div>
						<div>
							<p class="text-sm text-base-content/70">CAP</p>
							<p class="font-medium">{formData.postalCode}</p>
						</div>
						<div>
							<p class="text-sm text-base-content/70">Provincia</p>
							<p class="font-medium">{formData.county}</p>
						</div>
						<div>
							<p class="text-sm text-base-content/70">Nazione</p>
							<p class="font-medium">{formData.country}</p>
						</div>
					</div>
				</div>
			</div>
			{#if formData.differentShippingAddress}
				<div class="mb-6">
					<h4 class="font-medium text-primary mb-4">Informazioni di spedizione</h4>
					<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
						<div class="space-y-4">
							<div class="grid grid-cols-2 gap-2">
								<div>
									<p class="text-sm text-base-content/70">Nome</p>
									<p class="font-medium">{shippingName}</p>
								</div>
								<div>
									<p class="text-sm text-base-content/70">Cognome</p>
									<p class="font-medium">{shippingSurname}</p>
								</div>
								<div class="col-span-2">
									<p class="text-sm text-base-content/70">Email</p>
									<p class="font-medium">{shippingEmail}</p>
								</div>
								<div>
									<p class="text-sm text-base-content/70">Telefono</p>
									<p class="font-medium">{shippingPhone || 'Non specificato'}</p>
								</div>
								<div>
									<p class="text-sm text-base-content/70">Cellulare</p>
									<p class="font-medium">{shippingMobilePhone}</p>
								</div>
							</div>
						</div>

						<div class="space-y-4">
							<div class="grid grid-cols-2 gap-2">
								<div class="col-span-2">
									<p class="text-sm text-base-content/70">Indirizzo</p>
									<p class="font-medium">{shippingAddress}</p>
								</div>
								<div>
									<p class="text-sm text-base-content/70">Città</p>
									<p class="font-medium">{shippingCity}</p>
								</div>
								<div>
									<p class="text-sm text-base-content/70">CAP</p>
									<p class="font-medium">{shippingPostalCode}</p>
								</div>
								<div>
									<p class="text-sm text-base-content/70">Provincia</p>
									<p class="font-medium">{shippingCounty}</p>
								</div>
								<div>
									<p class="text-sm text-base-content/70">Nazione</p>
									<p class="font-medium">{shippingCountry}</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			{/if}

			<div class="space-y-4 mb-6">
				<h4 class="font-medium text-primary">Dettagli Pagamento:</h4>
				<p class="font-medium">{formData.paymentType}</p>

				<div class="overflow-x-auto">
					<table class="table table-zebra w-full">
						<thead>
							<tr>
								<th>Prodotto</th>
								<th class="text-right">Quantità</th>
								<th class="text-right">Prezzo</th>
							</tr>
						</thead>
						<tbody>
							{#each $cartProducts as item}
								<tr>
									<td>{item.title}</td>
									<td class="text-right">{item.orderQuantity || 1}</td>
									<td class="text-right">€ {item.price.toFixed(2)}</td>
								</tr>
							{/each}

							<tr class="text-info">
								<td colspan="2">Spedizione</td>
								<td class="text-right">
									<span>
										{formData.storePickUp ? '€ 0.00 Ritiro in sede' : `€ ${calculateDeliveryFee(subTotal()).toFixed(2)}`}
									</span>
								</td>
							</tr>

							<!-- {#if discountList.length > 0 || formData.usePoint}
								<tr class="text-success">
									<td colspan="2">Sconto</td>
									<td class="text-right">- € {totalDiscount().toFixed(2)}</td>
								</tr>
							{/if} -->

							{#if totalDiscount() > 0}
								<tr>
									<td colspan="2" class="font-bold text-right text-success">Sconto:</td>
									<td class="font-bold text-right text-success">- € {totalDiscount().toFixed(2)}</td>
								</tr>
							{/if}
						</tbody>
						<tfoot>
							<tr>
								<th colspan="2">Totale</th>
								<th class="text-right">
									{#if $cartProducts.length > 0}
										€ {Math.max(0, grandTotal()).toFixed(2)}
									{/if}
								</th>
							</tr>
						</tfoot>
					</table>
				</div>
				{#if formData.paymentType === 'Bonifico bancario' && grandTotal() > 0}
					<div class="card bg-base-100 shadow-xl p-6">
						<h3 class="text-xl font-semibold mb-4">Dettagli Bonifico Bancario</h3>
						<p>Effettua un bonifico bancario alle seguenti coordinate:</p>
						<p><strong>IBAN:</strong> IT93 R076 0111 5000 0102 3646 647</p>
						<p><strong>BIC/SWIFT:</strong> BPPIITRRXXX</p>
						<p><strong>INTESTATO A:</strong> ASSOCIAZIONE DIEN CHAN BUI QUOC CHAU Italia</p>
						<p>VIA TICINO 12F, 25015, DESENZANO DEL GARDA, BRESCIA</p>
						<br />
						<p>Si prega di includere il tuo ID ordine nella causale del bonifico. Il tuo ordine sarà elaborato dopo la conferma del pagamento.</p>
					</div>
				{:else if formData.paymentType === 'Bonifico bancario' && grandTotal() === 0 && formData.usePoint}
					<div class="card bg-base-100 shadow-xl p-6">
						<h3 class="text-xl font-semibold mb-4">Pagamento con punti: {pointsDiscount()}</h3>
					</div>
				{/if}

				{#if stripeError}
					<div class="card bg-base-100 shadow-xl p-6">
						<h3 class="text-xl font-semibold mb-4">ERRORE PAGAMENTO:</h3>
						<p class="text-error text-sm mt-2">{stripeError}</p>
					</div>
				{/if}

				<!-- {#if formData.paymentType === 'Carta di credito'}
					<div class="card bg-base-100 shadow-xl p-6">
						<h3 class="text-xl font-semibold mb-4">Pagamento:</h3>

						{#if paymentIntentId}
							<div class="alert alert-success">
								<Check size={20} />
								<span>Carta verificata</span>
							</div>
						{:else}
							<div class="alert alert-warning">
								<CircleX size={20} />
								<span>Devi verificare la carta per procedere con l'ordine.</span>
							</div>
						{/if}
					</div>
				{/if} -->
			</div>

			<!-- <div class="space-y-4">
					<h4 class="font-medium text-primary">Metodo di Pagamento</h4>

					<div class="grid grid-cols-1 md:grid-cols-3 gap-4">
						<label
							class="card bg-base-100 border-2 hover:border-primary hover:bg-base-200 cursor-pointer transition-all p-4 flex flex-col items-center justify-center gap-2"
							class:border-primary={formData.paymentType === 'Bonifico bancario'}
							class:bg-base-200={formData.paymentType === 'Bonifico bancario'}
						>
							<input
								type="radio"
								name="payment"
								value="Bonifico bancario"
								class="hidden"
								bind:group={formData.paymentType}
							/>
							<Landmark class="h-8 w-8 text-primary" />
							<span class="text-center font-medium">Bonifico bancario Bancario</span>
						</label>

						<label
							class="card bg-base-100 border-2 hover:border-primary hover:bg-base-200 cursor-pointer transition-all p-4 flex flex-col items-center justify-center gap-2"
							class:border-primary={formData.paymentType === 'paypal'}
							class:bg-base-200={formData.paymentType === 'paypal'}
						>
							<input
								type="radio"
								name="payment"
								value="paypal"
								class="hidden"
								bind:group={formData.paymentType}
							/>
							<CreditCard class="h-8 w-8 text-primary" />
							<span class="text-center font-medium">Paypal</span>
						</label>

						<label
							class="card bg-base-100 border-2 hover:border-primary hover:bg-base-200 cursor-pointer transition-all p-4 flex flex-col items-center justify-center gap-2"
							class:border-primary={formData.paymentType === 'contanti'}
							class:bg-base-200={formData.paymentType === 'contanti'}
						>
							<input
								type="radio"
								name="payment"
								value="contanti"
								class="hidden"
								bind:group={formData.paymentType}
							/>
							<HandCoins class="h-8 w-8 text-primary" />
							<span class="text-center font-medium">Contanti (all'inizio corso)</span>
						</label>
					</div>
				</div> -->
			<form method="POST" action={postAction} use:enhance={formSubmit} class="" bind:this={formEl}>
				<input type="hidden" name="name" value={formData.name} />
				<input type="hidden" name="surname" value={formData.surname} />
				<input type="hidden" name="email" value={formData.email} />
				<!-- {#if !auth}
					<input type="hidden" name="password1" value={password1} />
					<input type="hidden" name="password2" value={password2} />
				{/if} -->
				<input type="hidden" name="address" value={formData.address} />
				<input type="hidden" name="city" value={formData.city} />
				<input type="hidden" name="county" value={formData.county} />
				<input type="hidden" name="postalCode" value={formData.postalCode} />
				<input type="hidden" name="country" value={formData.country} />
				<input type="hidden" name="phone" value={formData.phone} />
				<input type="hidden" name="mobilePhone" value={formData.mobilePhone} />
				<input type="hidden" name="payment" value={formData.paymentType} />
				<input type="hidden" name="cart" value={JSON.stringify(cart)} />
				<input type="hidden" name="totalValue" value={Math.max(0, grandTotal())} />
				<input type="hidden" name="discountList" value={JSON.stringify(discountList)} />
				<input type="hidden" name="newPointsBalance" value={newPointsBalance()} />
				<input type="hidden" name="usedPoints" value={pointsDiscount()} />
				<input type="hidden" name="usePoint" value={formData.usePoint} />
				<input type="hidden" name="storePickUp" value={formData.storePickUp} />
				<!-- <input type="hidden" name="paymentMethodId" value={paymentMethodId || null} /> -->
				<input type="hidden" name="paymentIntentId" value={paymentIntentId} />
				<input type="hidden" name="shippingName" value={formData.storePickUp ? '' : shippingName} />
				<input type="hidden" name="shippingSurname" value={formData.storePickUp ? '' : shippingSurname} />
				<input type="hidden" name="shippingEmail" value={formData.storePickUp ? '' : shippingEmail} />
				<input type="hidden" name="shippingPhone" value={formData.storePickUp ? '' : shippingPhone} />
				<input type="hidden" name="shippingMobilePhone" value={formData.storePickUp ? '' : shippingMobilePhone} />
				<input type="hidden" name="shippingAddress" value={formData.storePickUp ? 'Ritiro in sede' : shippingAddress} />
				<input type="hidden" name="shippingCity" value={formData.storePickUp ? '' : shippingCity} />
				<input type="hidden" name="shippingCounty" value={formData.storePickUp ? '' : shippingCounty} />
				<input type="hidden" name="shippingPostalCode" value={formData.storePickUp ? '' : shippingPostalCode} />
				<input type="hidden" name="shippingCountry" value={formData.storePickUp ? '' : shippingCountry} />

				<label for="orderNotes" class="label">
					<span class="label-text font-medium">Note per l'ordine (opzionale)</span>
				</label>
				<textarea
					id="orderNotes"
					name="orderNotes"
					class="textarea textarea-bordered h-24 w-full"
					placeholder="Aggiungi qui eventuali note o istruzioni speciali per il tuo ordine..."
					bind:value={formData.orderNotes}
				></textarea>

				<div class="modal-action">
					<button type="button" class="btn btn-outline btn-error" onclick={onCloseModal}> Annulla </button>

					<!-- <button type="submit" class="btn btn-primary" disabled={loading || (formData.paymentType === 'Carta di credito' && !paymentMethodId)}>
						{#if loading}
							<span class="loading loading-spinner"></span>
							Elaborazione...
						{:else}
							Conferma Acquisto
						{/if}
					</button> -->

					<button type="button" class="btn btn-primary" onclick={handleFinalSubmit} disabled={loading || stripeError != null}>
						{#if loading}
							<span class="loading loading-spinner"></span>
							Elaborazione...
						{:else}
							Conferma Acquisto
						{/if}
					</button>
				</div>
			</form>
		</div>
	</Modal>
{/if}

{#if currentModal == 'success'}
	<dialog id="success-modal" class="modal modal-open">
		<div class="modal-box text-center">
			<div class="w-20 h-20 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-4">
				<CircleCheckBig size={40} class="text-success" />
			</div>
			<h3 class="font-bold text-xl mb-2">Ordine Confermato</h3>
			<p class="py-2">Puoi vedere lo storico ordini nell'AREA PERSONALE.</p>
			<div class="modal-action justify-center">
				<button class="btn btn-primary" onclick={onCloseModal}> Chiudi </button>
			</div>
		</div>
		<form method="dialog" class="modal-backdrop">
			<button onclick={onCloseModal}>close</button>
		</form>
	</dialog>
{/if}

{#if currentModal == 'newUser'}
	<dialog id="success-login-modal" class="modal modal-open">
		<div class="modal-box text-center">
			<div class="w-20 h-20 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-4">
				<CircleCheckBig size={40} class="text-success" />
			</div>
			<h3 class="font-bold text-xl mb-2">Ordine Confermato</h3>
			<p class="py-2 font-medium">Ora puoi fare LOGIN con EMAIL e PASSWORD</p>
			<p class="py-1">per completare il PROFILO e vedere il tuo STORICO ordini</p>
			<div class="modal-action justify-center">
				<button class="btn btn-primary" onclick={onCloseModal}> Chiudi </button>
			</div>
		</div>
		<form method="dialog" class="modal-backdrop">
			<button onclick={onCloseModal}>close</button>
		</form>
	</dialog>
{/if}

{#if currentModal == 'rememberCoupon'}
	<dialog id="success-modal" class="modal modal-open">
		<div class="modal-box text-center">
			<div class="w-20 h-20 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-4">
				<Info size={40} class="text-success" />
			</div>
			<h3 class="font-bold text-xl mb-2">Hai qualche codice sconto da usare?</h3>
			<p class="py-2">Prima di procedere all'acquisto inserisci i codici sconti per attivarli in fase di conferma ordine.</p>
			<div class="modal-action justify-center">
				<button class="btn btn-primary" onclick={onCloseModal}> Chiudi </button>
				<button class="btn btn-primary" onclick={() => onClickModal('new', null)}>
					Continua l'acquisto <HandCoins size={20} class="text-white" /></button
				>
			</div>
		</div>
		<form method="dialog" class="modal-backdrop">
			<button onclick={onCloseModal}>close</button>
		</form>
	</dialog>
{/if}
