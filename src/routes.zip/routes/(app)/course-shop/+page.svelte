<script lang="ts">
	//import { goto, invalidateAll } from '$app/navigation';
	//import { notification } from '$lib/stores/notifications';
	import { Image } from '@unpic/svelte';
	import { tick } from 'svelte';

	import CartFloat from '$lib/components/CartFloat.svelte';
	import { cartProducts } from '$lib/stores/cart';
	import {
		ChevronDown,
		ShieldAlert,
		Check,
		CalendarSearch,
		UserSearch,
		TextSearch,
		MapPinned,
		SlidersHorizontal,
		CircleX,
		Tags,
		BookOpen,
		Clock,
		MapPin,
		CircleUser,
		MessageCircleWarning,
		Info,
		Calendar
	} from 'lucide-svelte';
	//import { province } from '$lib/stores/arrays.js';

	const { data } = $props();
	const { getTable, getRiflessologi, getLayout, auth, userData } = data;
	let coursesList = $state(getTable);
	//console.log('getRiflessologi', getRiflessologi);
	let resetActive = $state(false);
	let currentSort = $state('dal più recente');

	// TODO TESTING:  toLocaleDateString for consistent localization
	//const currentMonthName = new Date().toLocaleDateString('it-IT', { month: 'long' });
	const nomiMesi = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
	const currentMonthIndex = new Date().getMonth();
	// const currentMonthName = nomiMesi[currentMonthIndex];

	const capitalizzaPrimaLettera = (stringa) => {
		return stringa.replace(/\b\w/g, (l) => l.toUpperCase());
	};

	// inizializzo ordinando visualizzanco prima quelli con giorno di svolgimento più recente
	// coursesList.sort((a, b) => new Date(b.eventStartDate) - new Date(a.eventStartDate));

	// cycle to count the number of courses in each province
	let numCoursesInProvince: any = $state({});
	coursesList.forEach((item) => {
		item.county.forEach((province) => {
			numCoursesInProvince[province] = (numCoursesInProvince[province] || 0) + 1;
		});
	});

	// Ordina le chiavi dell'oggetto in ordine alfabetico
	const sortedNumCoursesInProvince: Record<string, number> = Object.keys(numCoursesInProvince)
		.sort((a, b) => {
			// Se "Online" è presente, mettiamolo in cima
			if (a === 'Online') return -1;
			if (b === 'Online') return 1;

			// Altrimenti ordina alfabeticamente
			return a.localeCompare(b);
		})
		.reduce(
			(acc, key) => {
				acc[key] = numCoursesInProvince[key];
				return acc;
			},
			{} as Record<string, number>
		);

	numCoursesInProvince = sortedNumCoursesInProvince;

	// Creare un oggetto per tenere traccia del conteggio per ogni mese
	let conteggioMesi = $state({});

	// Populate conteggioMesi with all 12 months, initialized to 0
	// for (let i = 0; i < 12; i++) {
	// 	const monthName = new Date(2000, i, 1).toLocaleDateString('it-IT', { month: 'long' }); // Use a fixed date to get month names
	// 	conteggioMesi[capitalizzaPrimaLettera(monthName)] = 0;
	// }

	// Inizializza il conteggio per ogni mese a 0
	nomiMesi.forEach((mese) => (conteggioMesi[mese] = 0));

	// Contare le occorrenze per ogni mese
	getTable.forEach((item) => {
		// const meseTesto = new Date(item.eventStartDate).toLocaleString('it-IT', { month: 'long' });
		// const mese = capitalizzaPrimaLettera(meseTesto);
		const dataEvento = new Date(item.eventStartDate);
		const meseIndex = dataEvento.getMonth(); // Get the month index of the event
		const mese = nomiMesi[meseIndex];
		conteggioMesi[mese]++;
	});

	// Creare un array con le informazioni per ogni mese
	// const informazioniMesi = Object.entries(conteggioMesi).map(([mese, conteggio]) => {
	// 	return {
	// 		mese,
	// 		conteggio
	// 	};
	// });
	const informazioniMesi = Object.entries(conteggioMesi).map(([mese, conteggio]) => {
		// Find the year for this month from the courses
		const anno = getTable.find((item) => {
			const dataEvento = new Date(item.eventStartDate);
			const meseIndex = dataEvento.getMonth();
			return nomiMesi[meseIndex] === mese;
		});
		const year = anno ? new Date(anno.eventStartDate).getFullYear() : '';

		return {
			anno: year,
			mese,
			conteggio
		};
	});

	const meseAttualeInfo = informazioniMesi.find((item) => item.mese === nomiMesi[currentMonthIndex]);
	const currentMonthName = meseAttualeInfo && meseAttualeInfo?.conteggio > 0 ? nomiMesi[currentMonthIndex] : nomiMesi[(currentMonthIndex + 1) % 12];
	// const meseAttualeInfo = informazioniMesi.find((item) => item.meseBase === nomiMesi[currentMonthIndex]);
	// const currentMonthName =
	// 	meseAttualeInfo && meseAttualeInfo?.conteggio > 0
	// 		? meseAttualeInfo.mese
	// 		: informazioniMesi.find((item) => item.meseBase === nomiMesi[(currentMonthIndex + 1) % 12])?.mese || '';

	let filtriAttivi = $state({
		mese: currentMonthName,
		provincia: '',
		evento: '',
		riflessologo: {
			id: '',
			name: '',
			surname: ''
		}
	});

	const onFilterReset = () => {
		// invalidateAll();
		resetActive = false;
		coursesList = getTable || [];
		// coursesList.sort((a, b) => new Date(b.eventStartDate) - new Date(a.eventStartDate));

		filtriAttivi = {
			mese: currentMonthName,
			// mese: '',
			provincia: '',
			evento: '',
			riflessologo: {
				id: '',
				name: '',
				surname: ''
			}
			//userId: ''
		};

		// chiude gli accordion
		const accordionList = ['accordion1', 'accordion2', 'accordion3', 'accordion4'];
		accordionList.forEach((item) => (document.getElementById(item).checked = false));
		// document.getElementById('accordion1').checked = false;
		updateFilter();
	};

	const updateFilter = () => {
		const workshopTitle = 'Workshop: 12 Massaggi mattutini';
		const massaggiMattutini = getTable.filter((item) => item.layoutView.title == workshopTitle);

		coursesList = getTable;
		// Evento
		if (filtriAttivi.evento) {
			coursesList = coursesList.filter((item) => item.layoutView.title == filtriAttivi.evento);
		}
		// mese
		if (filtriAttivi.mese) {
			// console.log('filtriAttivi.mese', filtriAttivi.mese.toLowerCase());

			const monthIndex = nomiMesi.indexOf(filtriAttivi.mese);
			//const monthIndex = new Date(Date.parse(`${filtriAttivi.mese.toLowerCase()} 1, 2000`)).getMonth(); // Using a dummy date to parse month name
			//console.log('monthIndex', monthIndex);

			coursesList = coursesList.filter((item) => {
				const eventMonth = new Date(item.eventStartDate).getMonth();
				return eventMonth === monthIndex;
			});

			if (massaggiMattutini.length > 0) {
				const checkArray = coursesList.some((item) => item.layoutView.title === workshopTitle);

				if (!checkArray) {
					coursesList.push(massaggiMattutini[0]);
				}
			}
		}
		// provincia
		if (filtriAttivi.provincia) {
			// coursesList = coursesList.filter((item) => item.county == filtriAttivi.provincia);
			coursesList = coursesList.filter((item) => item.county.some((county) => county === filtriAttivi.provincia));
		}
		// riflessologo
		if (filtriAttivi.riflessologo.id && filtriAttivi.riflessologo.id.length > 0) {
			coursesList = coursesList.filter((item) => item.userId == filtriAttivi.riflessologo.id);
		}
	};
	updateFilter();

	const onClickFilterEvent = async (eventSelected) => {
		resetActive = true;
		filtriAttivi.evento = eventSelected;
		// console.log('filtriAttivi.evento', filtriAttivi.evento);
		updateFilter();
	};
	const onClickFilterMonth = async (monthSelected) => {
		resetActive = true;
		filtriAttivi.mese = monthSelected;
		updateFilter();
	};
	const onClickFilterProvincia = async (provinciaSelected) => {
		resetActive = true;
		filtriAttivi.provincia = provinciaSelected;
		updateFilter();
	};
	const onClickFilterRiflessologo = async (id, name, surname) => {
		resetActive = true;
		// filtriAttivi.riflessologo = id;
		filtriAttivi.riflessologo.id = id;
		filtriAttivi.riflessologo.name = name;
		filtriAttivi.riflessologo.surname = surname;
		updateFilter();
	};

	// sort
	// const sortItems = (option) => {
	// 	switch (option) {
	// 		case 'expensive':
	// 			currentSort = 'dal più costoso';
	// 			return coursesList.sort((a, b) => (b.layoutView?.price ?? 0) - (a.layoutView?.price ?? 0));
	// 		case 'cheap':
	// 			currentSort = 'dal più economico';
	// 			return coursesList.sort((a, b) => (a.layoutView?.price ?? 0) - (b.layoutView?.price ?? 0));
	// 		case 'recent':
	// 			currentSort = 'dal più recente';
	// 			return coursesList.sort((a, b) => new Date(b.eventStartDate) - new Date(a.eventStartDate));
	// 		case 'oldest':
	// 			currentSort = 'dal meno recente';
	// 			return coursesList.sort((a, b) => new Date(a.eventStartDate) - new Date(b.eventStartDate));

	// 		default:
	// 			return coursesList;
	// 	}
	// };

	$effect(() => {
		if (coursesList) {
			tick().then(() => {
				const element = document.getElementById('top');
				if (element) {
					element.scrollIntoView({ behavior: 'smooth' }); // smooth / instant
				}
			});
		}
	});
</script>

<svelte:head>
	<title>Lista corsi</title>
</svelte:head>

<div class="bg-base-200 grid grid-cols-12 grid-rows-[min-content] gap-y-12 p-4 lg:gap-x-8 lg:p-8">
	<!-- Filter column -->
	<section class="col-span-12 xl:col-span-2 bg-base-100 rounded-lg shadow-md border border-base-200 overflow-hidden">
		<div class="flex flex-col w-auto">
			<!-- Filter Header -->
			<div class="bg-primary text-primary-content p-4 relative overflow-hidden">
				<div class="absolute inset-0 opacity-20">
					<SlidersHorizontal class="w-32 h-32 -rotate-12 absolute -right-8 -bottom-8" />
				</div>
				<h2 class="text-xl font-bold relative z-10">Filtri</h2>
				<p class="text-sm opacity-90 mt-1 relative z-10">Affina la tua ricerca</p>
			</div>

			<!-- Filter Body -->
			<div class="p-4 space-y-4">
				<!-- Event Filter -->
				<div class="collapse collapse-arrow bg-base-100 border border-base-200 rounded-lg hover:border-primary/30 transition-colors duration-200">
					<input id="accordion1" type="checkbox" class="peer" />
					<div class="collapse-title bg-base-200 text-base-content peer-checked:bg-blue-300 peer-checked:font-bold">
						<span class="inline-flex items-center">
							<b><TextSearch class="-mt-1 mr-2" /> Evento</b>
							{#if filtriAttivi?.evento.length > 0}
								<Check class="ml-1" color="green" />
							{/if}
						</span>
					</div>
					<div class="collapse-content bg-blue-50 text-base-content peer-checked:bg-base-100 max-h-[250px] overflow-y-auto">
						<ul class="list-none -mx-4 divide-y divide-base-200/70">
							{#each getLayout as option}
								<li>
									<button
										type="button"
										class="p-3 cursor-pointer transition-all duration-300 flex items-center w-full
                {filtriAttivi.evento == option.title ? 'bg-orange-200 text-red-900 font-bold' : 'hover:bg-blue-200 hover:text-blue-900'}
"
										onclick={() => onClickFilterEvent(option.title)}
									>
										<!-- <span class="flex-1">{option.title} </span> -->
										<span class="flex-1 text-center font-semibold">
											{option.title}
											<Image
												layout="constrained"
												aspectRatio={1}
												src={option.urlPic || '/images/placeholder.jpg'}
												alt={option.title}
												class="h-full max-h-20 w-auto object-contain rounded-lg hover:scale-80 transition-transform duration-500 block mx-auto"
											/>
										</span>
										{#if filtriAttivi.evento == option.title}
											<Check size={18} class="flex-shrink-0 text-green-600" />
										{/if}
									</button>
								</li>
							{/each}
						</ul>
					</div>
				</div>

				<!-- Month Filter -->
				<div class="collapse collapse-arrow bg-base-100 border border-base-200 rounded-lg hover:border-primary/30 transition-colors duration-200">
					<input id="accordion2" type="checkbox" class="peer" />
					<div class="collapse-title bg-base-200 text-base-content peer-checked:bg-blue-300 peer-checked:font-bold">
						<span class="inline-flex items-center">
							<b><CalendarSearch class="-mt-1 mr-2" /> Mese</b>
							{#if filtriAttivi.mese.length > 0}
								<Check class="ml-1" color="green" />
							{/if}
						</span>
					</div>
					<div class="collapse-content bg-base-100 text-base-content peer-checked:bg-base-100 max-h-[250px] overflow-y-auto">
						<ul class="list-none -mx-4 divide-y divide-base-200/70">
							{#each informazioniMesi as { anno, mese, conteggio }}
								<li>
									<button
										type="button"
										class="p-3 cursor-pointer transition-all duration-300 flex items-center justify-between
                {filtriAttivi.mese == mese ? 'bg-orange-200 text-red-900 font-bold' : 'hover:bg-blue-200 hover:text-blue-900'}
                  {conteggio == 0 ? 'text-gray-400 pointer-events-none opacity-50' : ''}"
										onclick={() => onClickFilterMonth(mese)}
									>
										<span>{mese} {anno}</span>
										<div class="flex items-center gap-2">
											<span class="badge badge-sm badge-ghost">{conteggio}</span>
											{#if filtriAttivi.mese == mese}
												<Check size={18} class="flex-shrink-0 text-green-600" />
											{/if}
										</div>
									</button>
								</li>
							{/each}
						</ul>
					</div>
				</div>

				<!-- Province Filter -->
				<div class="collapse collapse-arrow bg-base-100 border border-base-200 rounded-lg hover:border-primary/30 transition-colors duration-200">
					<input id="accordion3" type="checkbox" class="peer" />
					<div class="collapse-title bg-base-200 text-base-content peer-checked:bg-blue-300 peer-checked:font-bold">
						<span class="inline-flex items-center">
							<b><MapPinned class="-mt-1 mr-2" /> Provincia</b>
							{#if filtriAttivi.provincia.length > 0}
								<Check class="ml-1" color="green" />
							{/if}
						</span>
					</div>
					<div class="collapse-content bg-base-100 text-base-content peer-checked:bg-base-100 max-h-[250px] overflow-y-auto">
						<ul class="list-none -mx-4 divide-y divide-base-200/70">
							{#each Object.entries(numCoursesInProvince) as [chiave, valore]}
								<li>
									<button
										type="button"
										class="p-3 cursor-pointer transition-all duration-300 flex items-center justify-between
                {filtriAttivi.provincia == chiave ? 'bg-orange-200 text-red-900 font-bold' : 'hover:bg-blue-200 hover:text-blue-900'}"
										onclick={() => onClickFilterProvincia(chiave)}
									>
										<span>{chiave}</span>
										<div class="flex items-center gap-2">
											<span class="badge badge-sm badge-ghost">{valore}</span>
											{#if filtriAttivi.provincia == chiave}
												<Check size={18} class="flex-shrink-0 text-green-600" />
											{/if}
										</div>
									</button>
								</li>
							{/each}
						</ul>
					</div>
				</div>

				<!-- Riflessologo Filter -->
				<div class="collapse collapse-arrow bg-base-100 border border-base-200 rounded-lg hover:border-primary/30 transition-colors duration-200">
					<input id="accordion4" type="checkbox" class="peer" />
					<div class="collapse-title bg-base-200 text-base-content peer-checked:bg-blue-300 peer-checked:font-bold">
						<span class="inline-flex items-center">
							<b><UserSearch class="-mt-1 mr-2" /> Riflessologo</b>
							{#if filtriAttivi.riflessologo.id.length > 0}
								<Check class="ml-1" color="green" />
							{/if}
						</span>
					</div>
					<div class="collapse-content bg-base-100 text-base-content peer-checked:bg-base-100 max-h-[250px] overflow-y-auto">
						<ul class="list-none -mx-4 divide-y divide-base-200/70">
							{#each getRiflessologi as item}
								<li>
									<button
										type="button"
										class="p-3 cursor-pointer transition-all duration-300 flex items-center justify-between
                {filtriAttivi.riflessologo.id === item.userId ? 'bg-orange-200 text-red-900 font-bold' : 'hover:bg-blue-200 hover:text-blue-900'}"
										onclick={() => onClickFilterRiflessologo(item.userId, item.name, item.surname)}
									>
										<span>{item.surname} {item.name}</span>
										{#if filtriAttivi.riflessologo.id === item.userId}
											<Check size={18} class="flex-shrink-0 text-green-600" />
										{/if}
									</button>
								</li>
							{/each}
						</ul>
					</div>
				</div>

				<!-- Reset Button -->
				{#if resetActive}
					<div class="pt-3 mt-2 border-t border-base-200">
						<button
							class="btn btn-sm w-full bg-red-200 border border-red-500 text-red-500 px-3 py-2 rounded-md hover:border-red-100 hover:bg-red-400 hover:text-red-200 flex items-center justify-center gap-2"
							onclick={onFilterReset}
						>
							<CircleX size={16} />
							Reset filtri
						</button>
					</div>
				{/if}
			</div>
		</div>
	</section>
	<!-- Product column -->
	<section class="col-span-12 xl:col-span-10 bg-base-100 rounded-lg">
		<div class="flex items-center p-4">
			<div class="btn btn-sm rounded-md cursor-default {coursesList.length > 0 ? 'bg-green-300 hover:bg-green-300' : 'bg-red-300 hover:bg-red-300'}">
				Corsi disponibili:
				<div class="badge rounded-md flex justify-center">
					<strong class="">{coursesList.length}</strong>
				</div>
			</div>
			<!-- Reset button -->
			{#if resetActive}
				<button
					class="btn btn-sm px-3 py-2 ml-4 rounded-md bg-red-200 border-red-500 text-red-500 hover:border-red-100 hover:bg-red-400 hover:text-red-200"
					onclick={onFilterReset}
				>
					<CircleX size={16} />
					Reset filtri
				</button>
			{/if}
			<!-- Sort button -->
			<!-- <div class="dropdown dropdown-end ml-auto">
				<button
					id="dropdownSortButton"
					class="btn btn-sm btn-primary btn-outline gap-2 rounded-md"
					tabindex="0"
				>
					<span class="flex items-center justify-center gap-2">
						Ordina: <span class="font-bold">{currentSort}</span>
						<ChevronDown />
					</span>
				</button>
				<ul class="dropdown-content menu p-2 shadow-lg bg-base-100 rounded-lg w-52 mt-1">
					<li>
						<button
							class="flex items-center {currentSort === 'dal più recente'
								? 'bg-primary/10 text-primary font-medium'
								: ''}"
							onclick={() => sortItems('recent')}
						>
							dal più recente
						</button>
					</li>
					<li>
						<button
							class="flex items-center {currentSort === 'dal meno recente'
								? 'bg-primary/10 text-primary font-medium'
								: ''}"
							onclick={() => sortItems('oldest')}
						>
							dal meno recente
						</button>
					</li>
					<li>
						<button
							class="flex items-center {currentSort === 'dal più costoso'
								? 'bg-primary/10 text-primary font-medium'
								: ''}"
							onclick={() => sortItems('expensive')}
						>
							dal più costoso
						</button>
					</li>
					<li>
						<button
							class="flex items-center {currentSort === 'dal meno costoso'
								? 'bg-primary/10 text-primary font-medium'
								: ''}"
							onclick={() => sortItems('cheap')}
						>
							dal meno costoso
						</button>
					</li>
				</ul>
			</div> -->
		</div>
		<!-- Visualizzazione filtri attivi e RESET -->
		{#if filtriAttivi.evento.length > 0 || filtriAttivi.mese.length > 0 || filtriAttivi.provincia.length > 0 || filtriAttivi.riflessologo.id.length > 0}
			<div class="flex items-center space-x-4 pb-3 px-4">
				<!-- Active filter -->
				<div class="text-gray-700">
					<span><Tags /></span>
					{#if filtriAttivi.evento.length > 0}
						<div class="badge badge-accent rounded-md">
							Evento: <strong class="pl-1">{filtriAttivi.evento}</strong>
						</div>
					{/if}
					{#if filtriAttivi.mese.length > 0}
						<div class="badge badge-accent rounded-md">
							Mese: <strong class="pl-1">{filtriAttivi.mese}</strong>
						</div>
					{/if}
					{#if filtriAttivi.provincia.length > 0}
						<div class="badge badge-accent rounded-md">
							Provincia: <strong class="pl-1">{filtriAttivi.provincia}</strong>
						</div>
					{/if}
					{#if filtriAttivi.riflessologo.id.length > 0}
						<div class="badge badge-accent rounded-md">
							Riflessologo: <strong class="pl-1">{filtriAttivi.riflessologo.name} {filtriAttivi.riflessologo.surname}</strong>
						</div>
					{/if}
				</div>
			</div>
		{/if}
		<!-- end ORDINA BUTTON -->
		<!-- CARD -->
		<div class="flex flex-wrap justify-center gap-4 pl-3 pb-4">
			{#if coursesList.length == 0}
				<div class="alert alert-warning shadow-lg text-center rounded-md mt-6 mx-auto w-full max-w-md">
					<div>
						<ShieldAlert />
						<br />
						<span class="mt-2 text-semibold"> Nessun corso trovato. Cambia parametri o resetta il filtro. </span>
					</div>
				</div>
			{/if}
			{#each coursesList as courseData, i}
				<div
					class="card overflow-hidden bg-base-100 rounded-xl shadow-lg border
	border-base-200 hover:shadow-xl transition-shadow duration-300 flex flex-col w-full sm:w-81"
					class:h-122={auth && userData?.membership.membershipStatus}
					class:h-136={!auth || !userData?.membership.membershipStatus}
				>
					<div class="relative px-6 pt-6 pb-2 bg-base-200/30 space-y-0">
						<a href="/course-detail/{courseData.prodId}">
							<div class="absolute -top-1 -right-1 z-10 opacity-85">
								<div class="relative">
									<div class="bg-gradient-to-r from-primary to-primary/80 text-primary-content px-4 py-2 rounded-bl-lg rounded-tr-lg shadow-md">
										<span class="text-xs font-semibold">PREZZO</span>
										<div class="flex items-baseline">
											{#if courseData.type === 'course'}
												<span class="text-2xl font-bold">€ {courseData.layoutView?.price || 'N/A'} </span>
											{:else if courseData.type === 'event'}
												<span class="text-2xl font-bold">€ 0 </span>
											{/if}
										</div>
									</div>
									<div
										class="absolute top-0 right-0 w-0 h-0 border-t-8 border-t-primary/80 border-r-8 border-r-transparent transform translate-x-full"
									></div>
								</div>
							</div>
							<div class="h-48 w-full flex items-center justify-center">
								<Image
									layout="constrained"
									aspectRatio={1}
									src={courseData.layoutView?.urlPic || '/images/placeholder.jpg'}
									alt={courseData.layoutView.title}
									class="h-full max-h-48 w-auto object-contain rounded-lg hover:scale-110 transition-transform duration-500"
								/>
							</div>
						</a>
					</div>

					<div class="card-body px-5 py-2 flex-grow">
						<a href="/course-detail/{courseData.prodId}">
							<h3 class="card-title text-lg font-bold text-primary flex items-start gap-2 mb-2">
								<BookOpen size={18} class="flex-shrink-0 mt-1" />
								<span>{courseData.layoutView.title}</span>
							</h3>
						</a>
						<div class="flex items-center gap-2 mb-2 text-sm">
							{#if courseData.layoutId === 'PYSYPA4QCTH1'}
								<span class="font-medium">Tutti i giorni</span>
								<Clock size={16} class="text-primary flex-shrink-0 ml-2" />
								<span>alle 7:00 e 9:00</span>
							{:else}
								<Calendar size={16} class="text-primary flex-shrink-0" />
								<span class="font-medium"><b>{new Date(courseData.eventStartDate).toLocaleDateString('it-IT')}</b></span>
								<Clock size={16} class="text-primary flex-shrink-0 ml-2" />
								<span>Dalle <b>{courseData.timeStartDate}</b></span>
							{/if}
						</div>

						<div class="flex items-center gap-2 mb-2 text-sm">
							<MapPin size={16} class="text-primary flex-shrink-0" />
							<span class="font-medium">
								{#if Array.isArray(courseData.county) && courseData.county.length > 0}
									{courseData.county.join(', ')}
								{:else if courseData.county}
									{courseData.county}
								{:else}
									Non specificato
								{/if}
							</span>
						</div>

						<div class="flex items-center gap-2 mb-1 text-sm">
							<CircleUser size={16} class="text-primary flex-shrink-0" />
							<span>Riflessologo: <b>{courseData.name} {courseData.surname}</b></span>
						</div>
						{#if !auth && courseData.type === 'course'}
							<div class="bg-amber-100 text-amber-800 p-2 rounded-md flex items-center gap-2 mb-3">
								<MessageCircleWarning size={16} class="flex-shrink-0" />
								<p class="text-xs font-medium">+25€ di tesseramento solo al primo corso</p>
							</div>
						{:else if !userData?.membership.membershipStatus && courseData.type === 'course'}
							<div class="bg-amber-100 text-amber-800 p-2 rounded-md flex items-center gap-2 mb-3">
								<MessageCircleWarning size={16} class="flex-shrink-0" />
								<p class="text-xs font-medium">+25€ di rinnovo tessera</p>
							</div>
						{/if}
					</div>

					<div class="px-5 pb-4 pt-0">
						<div class="divider my-1"></div>
						<div class="card-actions flex justify-between items-center w-full gap-2">
							<a class="btn btn-primary flex-1 rounded-md flex items-center gap-1" href="/course-detail/{courseData.prodId}">
								<Info size={20} />
								Visualizza
							</a>
						</div>
					</div>
				</div>
			{/each}
		</div>
		<!-- end CARD -->
	</section>
</div>
{#if $cartProducts.length > 0}
	<CartFloat />
{/if}

<style>
</style>
